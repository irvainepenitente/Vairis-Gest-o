self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', event => event.waitUntil(self.clients.claim()));
self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET' || request.mode !== 'navigate' || new URL(request.url).origin !== self.location.origin) return;
  event.respondWith(fetch(request).catch(() => new Response('<!doctype html><html lang="pt-BR"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Vairis Gestão</title><body style="font:18px system-ui;background:#061c34;color:#fff;padding:32px"><h1>Vairis Gestão</h1><p>Sem conexão. Conecte-se à internet para acessar seu sistema.</p><button onclick="location.reload()" style="font:inherit;padding:12px">Tentar novamente</button></body></html>', { headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' } })));
});
