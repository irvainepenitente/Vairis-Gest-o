type StorageEnv = { DOCUMENTS?: R2Bucket };
const json = (value: unknown, status = 200) => Response.json(value, { status, headers: { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
export async function documents(request: Request, env: StorageEnv): Promise<Response> {
  const user = request.headers.get('oai-authenticated-user-id');
  if (!user) return json({ error: 'Entre na sua conta para acessar documentos.' }, 401);
  if (!env.DOCUMENTS) return json({ error: 'O armazenamento está indisponível. Tente novamente.' }, 503);
  const bucket = env.DOCUMENTS;
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(user)));
  const prefix = 'users/' + Array.from(digest).map(b=>b.toString(16).padStart(2,'0')).join('') + '/';
  const url = new URL(request.url);
  if (request.method === 'POST') {
    const origin = request.headers.get('Origin');
    if (!origin || origin !== url.origin) return json({error:'Origem de envio inválida.'},403);
  }
  try {
    if (url.pathname === '/api/documents' && request.method === 'GET') {
      const records: unknown[] = []; let cursor: string | undefined;
      do { const listing = await bucket.list({ prefix, include: ['customMetadata'], cursor });
        for (const obj of listing.objects) if (obj.key.endsWith('/original') && obj.customMetadata?.record) { try { records.push(JSON.parse(obj.customMetadata.record)); } catch {} }
        cursor = listing.truncated ? listing.cursor : undefined;
      } while(cursor);
      return json(records.sort((a:any,b:any)=>b.created.localeCompare(a.created)));
    }
    if (url.pathname === '/api/documents' && request.method === 'POST') {
      if(Number(request.headers.get('content-length')||0)>32*1024*1024) return json({error:'Envio muito grande.'},413);
      const body = await request.formData(); const file = body.get('file'); const raw = body.get('extraction');
      if (!(file instanceof File) || typeof raw !== 'string') return json({error:'Arquivo inválido.'},400);
      if (!/\.(pdf|xlsx|xls|csv)$/i.test(file.name) || file.size>20*1024*1024 || raw.length>10*1024*1024) return json({error:'Use PDF, Excel ou CSV de até 20 MB. A extração deve ter até 10 MB.'},400);
      let extraction; try { extraction=JSON.parse(raw); } catch { return json({error:'Dados extraídos inválidos.'},400); }
      if(!Array.isArray(extraction.rows)||!Array.isArray(extraction.columns)||!extraction.columns.every((c:unknown)=>typeof c==='string')||!extraction.rows.every((r:unknown)=>r!==null&&typeof r==='object'&&!Array.isArray(r))) return json({error:'Formato do relatório inválido.'},400);
      const id=crypto.randomUUID(); const record={id,name:file.name.slice(0,240),size:file.size,created:new Date().toISOString(),kind:file.name.split('.').pop()!.toUpperCase(),records:extraction.rows.length};
      await bucket.put(prefix+id+'/report',raw,{httpMetadata:{contentType:'application/json'}});
      try { await bucket.put(prefix+id+'/original',file.stream(),{customMetadata:{record:JSON.stringify(record)},httpMetadata:{contentType:'application/octet-stream'}}); }
      catch(e) { await bucket.delete(prefix+id+'/report'); throw e; }
      return json(record,201);
    }
    const id=url.pathname.slice('/api/documents/'.length);
    if (request.method==='GET' && /^[a-f0-9-]{36}$/.test(id)) {
      const report=url.searchParams.get('report')==='1'; const original=await bucket.head(prefix+id+'/original');
      if(!original) return json({error:'Documento não encontrado.'},404);
      const item=await bucket.get(prefix+id+(report?'/report':'/original'));
      if(!item) return json({error:'Documento não encontrado.'},404);
      const record=JSON.parse(original.customMetadata?.record||'{}');
      return new Response(item.body,{headers:{'Content-Type':report?'application/json':'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...(!report?{'Content-Disposition':"attachment; filename*=UTF-8''"+encodeURIComponent(record.name||'documento')}: {})}});
    }
    return json({error:'Rota não encontrada.'},404);
  } catch(e) { console.error('documents operation failed',e); return json({error:'Não foi possível concluir a operação. Tente novamente.'},503); }
}
