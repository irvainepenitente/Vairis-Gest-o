import { validateBalance, sameEntity, type Balance } from '../lib/balance';
const json=(v:unknown,status=200)=>Response.json(v,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
export async function balances(request:Request,env:{DOCUMENTS?:R2Bucket}) {
  const user=request.headers.get('oai-authenticated-user-id'); if(!user)return json({error:'Entre na sua conta.'},401);
  if(!env.DOCUMENTS)return json({error:'Armazenamento indisponível. Tente novamente.'},503);
  const hash=new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(user)));
  const prefix='balances/'+Array.from(hash).map(x=>x.toString(16).padStart(2,'0')).join('')+'/';
  const url=new URL(request.url); const bucket=env.DOCUMENTS;
  if(request.method==='POST' && request.headers.get('Origin')!==url.origin)return json({error:'Origem de envio inválida.'},403);
  try {
    if(url.pathname==='/api/balances' && request.method==='GET') {
      const records:unknown[]=[];let cursor:string|undefined;
      do {const page=await bucket.list({prefix,cursor,include:['customMetadata']});for(const item of page.objects)if(item.key.endsWith('/data')&&item.customMetadata?.record)records.push(JSON.parse(item.customMetadata.record));cursor=page.truncated?page.cursor:undefined;}while(cursor);
      return json(records);
    }
    if(url.pathname==='/api/balances' && request.method==='POST') {
      if(Number(request.headers.get('Content-Length')||0)>24*1024*1024)return json({error:'Arquivo muito grande.'},413);
      const form=await request.formData();const raw=form.get('data');const file=form.get('file');
      if(typeof raw!=='string'||raw.length>4*1024*1024||!(file instanceof File)||file.size>20*1024*1024||!/\.(xlsx|xls|csv|pdf)$/i.test(file.name))return json({error:'Use Excel, CSV ou PDF de até 20 MB.'},400);
      let b:Balance;try{b=JSON.parse(raw);}catch{return json({error:'Dados inválidos.'},400);}
      const error=validateBalance(b);if(error)return json({error},400);
      let cursor:string|undefined;
      do {const page=await bucket.list({prefix,cursor,include:['customMetadata']});for(const item of page.objects)if(item.key.endsWith('/data')&&item.customMetadata?.record){const old=JSON.parse(item.customMetadata.record);if(sameEntity(old.entity,b.entity)&&old.period===b.period)return json({error:'Esse mês já está salvo para a entidade. Selecione outro período.'},409);}cursor=page.truncated?page.cursor:undefined;}while(cursor);
      const id=crypto.randomUUID();
      const record={id,entity:b.entity.trim(),period:b.period,basis:b.basis,filename:file.name.slice(0,240),created:new Date().toISOString()};
      const saved={...b,...record};
      await bucket.put(prefix+id+'/original',file.stream(),{httpMetadata:{contentType:'application/octet-stream'}});
      try{await bucket.put(prefix+id+'/data',JSON.stringify(saved),{customMetadata:{record:JSON.stringify(record)},httpMetadata:{contentType:'application/json'}});}catch(e){await bucket.delete(prefix+id+'/original');throw e;}
      return json(saved,201);
    }
    const match=url.pathname.match(/^\/api\/balances\/([a-f0-9-]{36})(\/original)?$/);
    if(match&&request.method==='GET') {
      const item=await bucket.get(prefix+match[1]+(match[2]?'/original':'/data'));if(!item)return json({error:'Balanço não encontrado.'},404);
      return new Response(item.body,{headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Type':match[2]?'application/octet-stream':'application/json',...(match[2]?{'Content-Disposition':'attachment; filename="balanco-original"'}:{})}});
    }
    return json({error:'Rota não encontrada.'},404);
  }catch(e){console.error('balance storage failed',e);return json({error:'Não foi possível carregar ou salvar. Seus dados de revisão foram mantidos; tente novamente.'},503);}
}
