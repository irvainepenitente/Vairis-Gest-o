type Env={AUTOMATION_RUNNER_URL?:string;AUTOMATION_RUNNER_TOKEN?:string};
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
export async function eventos(request:Request,env:Env){
  const user=request.headers.get('oai-authenticated-user-id');if(!user)return json({error:'Entre na sua conta.'},401);
  const url=new URL(request.url),path=url.pathname;
  if(request.method==='POST'&&request.headers.get('Origin')!==url.origin)return json({error:'Origem de envio inválida.'},403);
  if(!['GET','POST'].includes(request.method))return json({error:'Método inválido.'},405);
  const allowed=path==='/api/eventos/status'&&request.method==='GET'||path==='/api/eventos/jobs'||/^\/api\/eventos\/jobs\/[0-9a-f-]{36}(\/image)?$/.test(path)&&request.method==='GET';
  if(!allowed)return json({error:'Não encontrado.'},404);
  if(!env.AUTOMATION_RUNNER_URL||!env.AUTOMATION_RUNNER_TOKEN){
    if(path==='/api/eventos/status')return json({connected:false,ready:false,message:'O robô Python está preparado. Aguardando conexão com a hospedagem.'});
    if(path==='/api/eventos/jobs'&&request.method==='GET')return json({job:null});
    return json({error:'Conecte a hospedagem do robô antes de iniciar a consulta.'},503);
  }
  try{
    const base=new URL(env.AUTOMATION_RUNNER_URL);if(base.protocol!=='https:'||base.username||base.password||base.search||base.hash)throw Error('Configuração inválida');
    const digest=new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(user)));
    const owner=Array.from(digest).map(x=>x.toString(16).padStart(2,'0')).join('');
    const headers:Record<string,string>={Authorization:'Bearer '+env.AUTOMATION_RUNNER_TOKEN,'X-Vairis-Owner':owner};
    let remote:string,body:string|undefined;
    if(path==='/api/eventos/status')remote='/status';
    else if(path==='/api/eventos/jobs'&&request.method==='GET')remote='/jobs/latest';
    else if(path==='/api/eventos/jobs'){remote='/jobs';headers['Content-Type']='application/json';body=JSON.stringify({id:crypto.randomUUID(),owner});}
    else remote=path.replace('/api/eventos','');
    const r=await fetch(new URL(remote,base),{method:request.method,headers,body,redirect:'error',signal:AbortSignal.timeout(12000)});
    if(path==='/api/eventos/status'){
      if(!r.ok)return json({connected:false,ready:false,message:'Não foi possível conectar ao servidor do robô. Confira a hospedagem.'});
      const data=await r.json() as {ready?:boolean};return json({connected:true,ready:data.ready===true,message:data.ready?'Servidor conectado. Pronto para testar a lista.':'Servidor conectado. O acesso ao Eventos APSo ainda precisa ser configurado.'});
    }
    if(path.endsWith('/image')){
      if(!r.ok||!r.headers.get('Content-Type')?.startsWith('image/png'))return json({error:'Imagem de conferência indisponível.'},404);
      return new Response(r.body,{headers:{'Content-Type':'image/png','Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'}});
    }
    if(!r.ok){if(r.status===409)return json({error:'O servidor precisa de revisão do acesso ou já tem uma consulta em andamento. Confira o status.'},409);if(r.status===404)return json({error:'Consulta não encontrada.'},404);throw Error('Servidor indisponível');}
    const data=await r.json();return json(data,r.status);
  }catch{return path==='/api/eventos/status'?json({connected:false,ready:false,message:'Servidor do robô indisponível. Tente verificar novamente.'}):json({error:'Não foi possível consultar o robô. Verifique novamente antes de iniciar outra consulta.'},503);}
}
