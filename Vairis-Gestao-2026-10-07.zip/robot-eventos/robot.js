(() => {
  'use strict';
  if (location.pathname !== '/system/lista_admin_pagtos.php' || document.getElementById('vairis-eventos-robot')) return;
  const key='vairis-eventos-test-v1', norm=t=>String(t||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
  const panel=document.createElement('section');panel.id='vairis-eventos-robot';panel.setAttribute('aria-label','Robô Vairis Eventos APSo');
  const shadow=panel.attachShadow({mode:'open'});
  shadow.innerHTML='<style>:host{position:fixed;right:16px;bottom:16px;z-index:2147483647;width:min(350px,calc(100vw - 32px));font:14px Arial,sans-serif}section{padding:18px;background:#06243b;color:#effaff;border:1px solid #43cddd;border-radius:14px;box-shadow:0 8px 30px #0005}h2{font-size:18px;margin:0 0 10px}p{line-height:1.5;margin:10px 0}button{font:inherit;font-weight:bold;padding:10px 12px;border:0;border-radius:7px;cursor:pointer;background:#42ccdb;color:#05243a;margin-right:8px}button:disabled{opacity:.5;cursor:wait}.secondary{background:#24465d;color:white}small{color:#b8d4df}div{display:flex;flex-wrap:wrap;gap:8px}</style><section><h2>Vairis · Eventos APSo</h2><p id="status" role="status">Entre na sua conta e clique em Testar. Vou selecionar Todos, filtrar e ordenar pela data de encerramento.</p><div><button id="run">Testar até aqui</button><button id="stop" class="secondary">Parar</button></div><p><small>Teste 1 · Não baixa extratos nesta etapa.</small></p></section>';
  document.documentElement.append(panel);
  const status=shadow.getElementById('status'),run=shadow.getElementById('run');let generation=0;
  const message=t=>{status.textContent=t;};
  const read=()=>{try{const s=JSON.parse(sessionStorage.getItem(key)||'null');return s&&Date.now()-s.started<120000?s:null;}catch{return null;}};
  const clear=()=>sessionStorage.removeItem(key);
  const pause=ms=>new Promise(r=>setTimeout(r,ms));
  function situation(){const options=[...document.querySelectorAll('select')].filter(s=>[...s.options].some(o=>norm(o.text)==='todos'));const labeled=options.filter(s=>norm(s.name+' '+s.id+' '+document.querySelector(`label[for="${CSS.escape(s.id)}"]`)?.textContent).includes('situ'));if(labeled.length===1)return labeled[0];if(options.length===1)return options[0];throw Error('Não identifiquei com segurança o campo Situação. Envie uma imagem desta tela para ajustarmos o robô.');}
  function filterButton(select){const area=select.closest('form')||document;const buttons=[...area.querySelectorAll('button,input[type="submit"],input[type="button"],a')].filter(b=>norm(b.value||b.textContent)==='filtrar'&&!panel.contains(b));if(buttons.length!==1)throw Error('Não identifiquei um único botão Filtrar. Envie uma imagem para ajustarmos este passo.');return buttons[0];}
  function tableInfo(){for(const table of document.querySelectorAll('table')){const header=[...table.querySelectorAll('thead th,thead td')].find(h=>norm(h.textContent)==='encerra em');if(header)return {table,header,index:[...header.parentElement.children].indexOf(header)};}throw Error('A coluna Encerra em não foi encontrada. Confira se a lista de eventos terminou de carregar.');}
  function dates(info){return [...info.table.querySelectorAll('tbody tr')].map(r=>r.children[info.index]?.textContent?.match(/(\d{2})\/(\d{2})\/(\d{4})/)).filter(Boolean).map(m=>Number(m[3]+m[2]+m[1]));}
  function descending(info){const aria=info.header.getAttribute('aria-sort');if(aria)return aria==='descending';if(/(^|\s)(sorting_desc|dt-ordering-desc)(\s|$)/.test(info.header.className))return true;if(/(^|\s)(sorting_asc|dt-ordering-asc)(\s|$)/.test(info.header.className))return false;const d=dates(info);return d.length>1&&new Set(d).size>1&&d.every((v,i)=>i===0||d[i-1]>=v);}
  async function sort(token){message('Todos selecionado e filtro aplicado. Conferindo a ordem de Encerra em…');let info;for(let i=0;i<40;i++){if(token!==generation)return;try{info=tableInfo();break;}catch{}await pause(250);}if(!info)throw Error('A lista não carregou. Confira o portal e tente novamente.');
    const rows=[...info.table.querySelectorAll('tbody tr')];const empty=rows.length===0||rows.every(r=>r.children.length===1&&/nenhum|nao ha|no matching|no data|sem registros|nenhum registro/.test(norm(r.textContent)));
    if(empty){clear();message('Filtro aplicado. Nenhum evento foi encontrado nesta lista.');return;}
    for(let clicks=0;clicks<3;clicks++){if(token!==generation)return;if(descending(info)){clear();message('Pronto: Situação Todos, filtro aplicado e Encerra em do mais recente para o mais antigo. Confira a lista e me conte se ficou correta.');return;}info.header.click();await pause(850);info=tableInfo();}
    throw Error('Cliquei em Encerra em, mas não consegui confirmar a ordem. Envie uma imagem da coluna e das primeiras datas para ajustarmos.');
  }
  async function execute(resume=false){const token=++generation;run.disabled=true;try{
    const select=situation(),all=[...select.options].find(o=>norm(o.text)==='todos');
    if(resume){if(select.value!==all.value)throw Error('O portal não manteve Situação Todos após o filtro. Precisamos ajustar este passo.');await sort(token);return;}
    const button=filterButton(select),before=document.querySelector('table tbody')?.textContent;
    select.value=all.value;select.dispatchEvent(new Event('input',{bubbles:true}));select.dispatchEvent(new Event('change',{bubbles:true}));
    sessionStorage.setItem(key,JSON.stringify({started:Date.now(),stage:'filtered'}));message('Situação Todos selecionada. Aplicando o filtro…');button.click();
    // Full-page navigation resumes from sessionStorage. For AJAX, wait for the list to change instead of sorting stale rows.
    for(let i=0;i<60;i++){await pause(250);if(token!==generation)return;if(document.querySelector('table tbody')?.textContent!==before){await pause(500);await sort(token);return;}}
    throw Error('Filtro enviado, mas não foi possível confirmar a atualização da lista. Confira a tela e envie uma imagem para ajustarmos.');
  }catch(e){clear();message(e.message||'Não foi possível concluir o teste.');}finally{if(token===generation)run.disabled=false;}}
  run.addEventListener('click',()=>execute());shadow.getElementById('stop').addEventListener('click',()=>{generation++;clear();run.disabled=false;message('Teste interrompido. Você pode conferir a lista ou iniciar novamente.');});
  if(read()?.stage==='filtered')execute(true);
})();
