export const categories = {
  ignore: 'Não incluir / totalizador', revenue: 'Receita', personnel: 'Despesa com pessoal', admin: 'Despesa administrativa', grant: 'Subvenções enviadas', expense: 'Outras despesas', cash: 'Disponibilidades', receivable: 'Contas a receber', payable: 'Contas a pagar', asset: 'Outros ativos', liability: 'Outros passivos', equity: 'Patrimônio líquido'
} as const;
export type Category = keyof typeof categories;
export type Account = { code: string; name: string; category: Category; value: number; budget: number | null; nature: 'D' | 'C' | ''; expected: 'D' | 'C' | ''; movement: string; due: string; mirror: string };
export const fields = { revenue: 'Receita', expense: 'Despesa', personnel: 'Pessoal', admin: 'Administrativo', cash: 'Disponibilidades', receivable: 'Contas a receber', payable: 'Contas a pagar', currentAssets: 'Ativo circulante', currentLiabilities: 'Passivo circulante', assets: 'Ativo total', liabilities: 'Passivo exigível total', equity: 'Patrimônio líquido', accumulatedResult: 'Resultado acumulado' } as const;
export type Metrics = Record<keyof typeof fields, number | null>;
export type Balance = { id?: string; created?: string; filename?: string; entity: string; period: string; basis: 'monthly' | 'ytd'; flowComplete: boolean; accounts: Account[]; metrics: Partial<Metrics>; limits: { personnel: number; admin: number; variation: number; amount: number; stale: number }; source?: { format:'AASI'; notes:string[]; personnelRatio:number|null; adminRatio:number|null; principal:number|null; reports:Balance[]; annualAccounts:Account[]; flags:{description:string;value:number}[] } };
export const money = (v: number | null) => v === null ? 'Não informado' : v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
export const percent = (v: number | null) => v === null ? 'Não disponível' : v.toLocaleString('pt-BR', { maximumFractionDigits: 2 }) + '%';
export const ratio = (a: number | null, b: number | null) => a === null || b === null || b <= 0 ? null : a / b;
export function parseNumber(v: unknown): number | null {
  if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  let s = String(v ?? '').trim(); if (!s || s === '-') return null;
  const negative = /^\(.*\)$/.test(s) || /-\s*$/.test(s);
  s = s.replace(/R\$|[\s()DC]/gi, '').replace(/-$/, '');
  if (s.includes(',')) s = s.replace(/\./g, '').replace(',', '.');
  else if (/^[-+]?\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, '');
  if (!/^[-+]?\d+(\.\d+)?$/.test(s)) return null;
  const n = Number(s); return Number.isFinite(n) ? (negative ? -Math.abs(n) : n) : null;
}
export const monthIndex = (p: string) => Number(p.slice(0,4))*12+Number(p.slice(5,7))-1;
export const sameEntity = (a:string,b:string) => a.trim().toLocaleLowerCase('pt-BR')===b.trim().toLocaleLowerCase('pt-BR');
export function validateBalance(b: Balance): string | null {
  if (!b || typeof b.entity !== 'string' || !b.entity.trim() || b.entity.length > 160) return 'Informe a entidade (até 160 caracteres).';
  if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(b.period) || !['monthly','ytd'].includes(b.basis) || typeof b.flowComplete !== 'boolean') return 'Período ou base inválidos.';
  if (!Array.isArray(b.accounts) || !b.accounts.length || b.accounts.length > 5000) return 'Inclua de 1 a 5.000 contas.';
  const codes = new Set<string>();
  for (const a of b.accounts) {
    if (!a || typeof a.code !== 'string' || !a.code.trim() || a.code.length > 100 || typeof a.name !== 'string' || !a.name.trim() || a.name.length > 300 || !Object.hasOwn(categories,a.category) || !Number.isFinite(a.value) || Math.abs(a.value)>1e15 || (a.budget !== null && (!Number.isFinite(a.budget) || Math.abs(a.budget)>1e15))) return 'Confira código, descrição, valor e orçamento das contas.';
    if (codes.has(a.code)) return 'Há códigos de conta repetidos. Use códigos únicos para evitar duplicidade.'; codes.add(a.code);
    if (!['','D','C'].includes(a.nature) || !['','D','C'].includes(a.expected) || typeof a.mirror !== 'string' || a.mirror.length > 100) return 'Natureza ou conta espelho inválida.';
    for (const d of [a.due,a.movement]) if (typeof d !== 'string' || (d && (!/^\d{4}-\d{2}-\d{2}$/.test(d) || !Number.isFinite(Date.parse(d))))) return 'Use datas válidas no formato AAAA-MM-DD.';
  }
  if (!b.metrics || typeof b.metrics !== 'object' || Array.isArray(b.metrics)) return 'Totais inválidos.';
  for (const [k,v] of Object.entries(b.metrics)) if (!(k in fields) || (v!==null && (typeof v!=='number' || !Number.isFinite(v) || Math.abs(v)>1e15))) return 'Totais inválidos.';
  if (!b.limits || ['personnel','admin','variation','amount','stale'].some(k=>typeof b.limits[k as keyof Balance['limits']] !== 'number' || !Number.isFinite(b.limits[k as keyof Balance['limits']]) || b.limits[k as keyof Balance['limits']]<0)) return 'Parâmetros inválidos.';
  if (b.source) {
    const s=b.source;
    if(s.format!=='AASI'||!Array.isArray(s.notes)||s.notes.length>20||!s.notes.every(n=>typeof n==='string'&&n.length<1000)||!Array.isArray(s.reports)||s.reports.length>12||!Array.isArray(s.annualAccounts)||s.annualAccounts.length>5000||!Array.isArray(s.flags)||s.flags.length>100) return 'Dados do relatório AASI inválidos.';
    if([s.personnelRatio,s.adminRatio,s.principal].some(n=>n!==null&&(typeof n!=='number'||!Number.isFinite(n))))return 'Índices AASI inválidos.';
    for(const r of s.reports)if(r.source||!sameEntity(r.entity,b.entity)||r.period>=b.period||validateBalance(r))return 'Histórico incorporado inválido.';
    if(s.annualAccounts.length&&validateBalance({...b,source:undefined,accounts:s.annualAccounts}))return 'Contas acumuladas inválidas.';
    if(s.flags.some(f=>typeof f.description!=='string'||f.description.length>500||typeof f.value!=='number'||!Number.isFinite(f.value)))return 'Avisos AASI inválidos.';
  }
  return null;
}
export function totals(b: Balance): Metrics {
  const m = Object.fromEntries(Object.keys(fields).map(k=>[k,b.metrics[k as keyof Metrics] ?? null])) as Metrics;
  const groups: Partial<Record<keyof Metrics, Category[]>> = { revenue:['revenue'], expense:['personnel','admin','grant','expense'], personnel:['personnel'], admin:['admin'], cash:['cash'], receivable:['receivable'], payable:['payable'] };
  for (const [key,cats] of Object.entries(groups)) {
    const k = key as keyof Metrics; const rows = b.accounts.filter(a=>cats.includes(a.category));
    const flow = ['revenue','expense','personnel','admin'].includes(k);
    if (m[k]===null && rows.length && (!flow || b.flowComplete)) m[k] = rows.reduce((sum,a)=>sum+a.value,0);
  }
  return m;
}
const flowKeys = ['revenue','expense','personnel','admin'] as const;
export function monthly(b: Balance, history: Balance[]): Metrics {
  const m = totals(b); if (b.basis==='monthly') return m;
  const prior = history.find(h=>sameEntity(h.entity,b.entity) && h.period.slice(0,4)===b.period.slice(0,4) && monthIndex(h.period)===monthIndex(b.period)-1 && h.basis==='ytd');
  if (b.period.endsWith('-01')) return m;
  const p = prior ? totals(prior) : null;
  for (const k of flowKeys) m[k] = m[k]!==null && p?.[k]!=null ? m[k]!-p[k]! : null;
  return m;
}
export type Alert = { priority: 'Alta' | 'Revisar'; account: string; text: string; recommendation: string };
export function analyze(b: Balance, all: Balance[]) {
  const embedded=b.source?.reports||[];
  all=[...all,...embedded.filter(e=>!all.some(a=>sameEntity(a.entity,e.entity)&&a.period===e.period))];
  const history = all.filter(h=>sameEntity(h.entity,b.entity) && h.period<b.period).sort((a,c)=>a.period.localeCompare(c.period));
  const previous = history.find(h=>monthIndex(h.period)===monthIndex(b.period)-1);
  const m = monthly(b,all); const p = previous ? monthly(previous,all) : null;
  const result = m.revenue===null || m.expense===null ? null : m.revenue-m.expense;
  const previousResult = !p || p.revenue===null || p.expense===null ? null : p.revenue-p.expense;
  const series = [...history,b].map(h=>({ period:h.period, ...monthly(h,all) }));
  const ytd = series.filter(h=>h.period.slice(0,4)===b.period.slice(0,4));
  const completeYear = ytd.length===Number(b.period.slice(5,7)) && ytd.every(h=>h.revenue!==null&&h.expense!==null);
  const accumulated = b.metrics.accumulatedResult ?? (b.basis==='ytd' && totals(b).revenue!==null && totals(b).expense!==null ? totals(b).revenue!-totals(b).expense! : completeYear ? ytd.reduce((s,h)=>s+h.revenue!-h.expense!,0) : null);
  const personnel = b.source ? b.source.personnelRatio : ratio(m.personnel,m.revenue); const admin = b.source ? b.source.adminRatio : ratio(m.admin,m.revenue);
  const alerts: Alert[] = [];
  const add = (priority:Alert['priority'],account:string,text:string,recommendation:string)=>alerts.push({priority,account,text,recommendation});
  for(const f of b.source?.flags||[])add('Alta','Aviso do relatório AASI',`${f.description}: ${money(f.value)}.`,'Confira a aba PA e os lançamentos que originaram a pendência.');
  const differences = b.accounts.filter(a=>a.category!=='ignore').map(a=>{
    const old=previous?.accounts.find(x=>x.code===a.code); const flow=['revenue','personnel','admin','grant','expense'].includes(a.category);
    const compatible = old && old.category===a.category && previous?.basis===b.basis;
    const current = flow && b.basis==='ytd' ? (b.period.endsWith('-01')?a.value:compatible?a.value-old!.value:null) : a.value;
    let before: number | null = compatible ? old!.value : null;
    if (flow && b.basis==='ytd' && previous && !previous.period.endsWith('-01')) {
      const older = history.find(h=>monthIndex(h.period)===monthIndex(previous.period)-1 && h.basis==='ytd' && h.period.slice(0,4)===previous.period.slice(0,4));
      const olderAccount=older?.accounts.find(x=>x.code===a.code && x.category===a.category); before=olderAccount&&old?old.value-olderAccount.value:null;
    }
    const delta=current===null||before===null?null:current-before; const variation=delta===null||before===null||before===0?null:delta/Math.abs(before)*100;
    if (delta!==null && Math.abs(delta)>=b.limits.amount && (variation===null ? delta!==0 : Math.abs(variation)>=b.limits.variation)) add('Revisar',a.name,`Variação de ${money(delta)}${variation!==null?' ('+percent(variation)+')':''} em relação ao mês anterior.`, 'Confira os lançamentos e documente a causa da variação.');
    if (a.nature && a.expected && a.nature!==a.expected && a.value!==0) add('Alta',a.name,'Saldo com natureza diferente da esperada.','Verifique lançamentos, reclassificações e a natureza definida.');
    if (a.value<0 && ['cash','receivable','payable'].includes(a.category)) add('Revisar',a.name,'Saldo negativo em uma conta de disponibilidade, recebimento ou pagamento.','Confirme se o sinal e a classificação estão corretos.');
    const end=Date.parse(b.period+'-01');
    if (a.movement && a.value!==0 && (end-Date.parse(a.movement))/(1000*60*60*24*30.44)>=b.limits.stale) add('Revisar',a.name,`Última movimentação informada em ${a.movement}.`,'Concilie o saldo com os documentos de suporte.');
    if (a.due && ['receivable','payable'].includes(a.category) && a.value>0 && a.due<b.period+'-01') add('Alta',a.name,`Vencimento informado em ${a.due}, anterior ao período analisado.`,'Verifique liquidação, cobrança ou negociação.');
    if (a.mirror) { const mirror=b.accounts.find(x=>x.code===a.mirror); if (!mirror) add('Revisar',a.name,'Conta espelho informada não encontrada.','Importe a conta correspondente.'); else if (Math.abs(Math.abs(a.value)-Math.abs(mirror.value))>0.01) add('Revisar',a.name,'Valores absolutos diferentes entre contas espelho.','Concilie as duas contas e suas contrapartidas.'); }
    return { ...a, current, before, delta, variation, budgetDelta:a.budget===null?null:a.value-a.budget };
  });
  if (personnel!==null && personnel*100>b.limits.personnel) add('Alta','Pessoal',`${percent(personnel*100)} da receita; parâmetro definido: ${percent(b.limits.personnel)}.`,'Revise a composição das despesas com pessoal.');
  if (admin!==null && admin*100>b.limits.admin) add('Alta','Administrativo',`${percent(admin*100)} da receita; parâmetro definido: ${percent(b.limits.admin)}.`,'Revise os maiores gastos administrativos.');
  if (m.currentLiabilities!==null && m.currentLiabilities>0 && m.currentAssets!==null && m.currentAssets<m.currentLiabilities) add('Revisar','Liquidez','Ativo circulante menor que o passivo circulante.','Avalie prazos de recebimento e vencimento antes de concluir sobre a capacidade de pagamento.');
  const check= m.assets!==null&&m.liabilities!==null&&m.equity!==null ? m.assets-m.liabilities-m.equity : null;
  if (check!==null && Math.abs(check)>0.01) add('Alta','Equação patrimonial',`Ativo menos passivo exigível e patrimônio líquido: ${money(check)}.`,'Confira totais e a inclusão do resultado no patrimônio líquido.');
  const lastSix = series.filter(h=>h.period<b.period && monthIndex(h.period)>=monthIndex(b.period)-6);
  const sixComplete=lastSix.length===6&&lastSix.every(h=>h.expense!==null);
  const meanExpense=sixComplete?lastSix.reduce((s,h)=>s+h.expense!,0)/6:null;
  if (meanExpense!==null&&meanExpense>0&&m.expense!==null&&m.expense>meanExpense*(1+b.limits.variation/100)&&m.expense-meanExpense>=b.limits.amount) add('Revisar','Despesas',`${percent((m.expense/meanExpense-1)*100)} acima da média dos últimos seis meses.`,'Revise gastos extraordinários e despesas recorrentes.');
  const priorYear=all.find(h=>sameEntity(h.entity,b.entity)&&h.period===`${Number(b.period.slice(0,4))-1}${b.period.slice(4)}`);
  const priorYearMetrics=priorYear?monthly(priorYear,all):null;
  const drivers=differences.filter(a=>a.delta!==null&&['revenue','personnel','admin','grant','expense'].includes(a.category)).map(a=>({...a,impact:a.category==='revenue'?a.delta!:-a.delta!})).sort((a,c)=>Math.abs(c.impact)-Math.abs(a.impact));
  const narrative=[result===null?'Resultado mensal indisponível: informe receitas e despesas do mês ou o acumulado e o mês anterior.':`O período apresentou ${result>=0?'superávit':'déficit'} de ${money(result)}.`, previousResult!==null&&result!==null?`A diferença em relação ao mês anterior foi de ${money(result-previousResult)}.`:'Comparação mensal depende de períodos consecutivos e da mesma entidade.', accumulated!==null?`Resultado acumulado: ${money(accumulated)}.`:'Acumulado indisponível: falta o total informado ou o histórico completo do ano.', alerts.length?`${alerts.length} ponto(s) merecem revisão; ${alerts.filter(a=>a.priority==='Alta').length} de alta prioridade.`:'Nenhum alerta foi encontrado pelas regras aplicáveis aos dados informados.'].join(' ');
  return {m,p,result,previousResult,accumulated,personnel,admin,alerts,differences,drivers,series,priorYearMetrics,narrative,meanExpense,projection:accumulated!==null&&result!==null?accumulated+result*(12-Number(b.period.slice(5,7))):null};
}
