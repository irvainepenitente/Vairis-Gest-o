import { parseNumber, type Account, type Category, categories } from './balance';
import {detectAasi,detectAasiPdf} from './aasi';
import type {Balance} from './balance';
export type Sheet = { name:string; rows:unknown[][] };
export async function readBalance(file:File):Promise<{sheets:Sheet[];text:string;detected?:Balance|null}> {
  if(file.size>20*1024*1024)throw Error('O limite é 20 MB por arquivo.');
  if(/\.pdf$/i.test(file.name)) {
    const pdf=await import('pdfjs-dist');pdf.GlobalWorkerOptions.workerSrc='/pdf.worker.min.mjs';
    const doc=await pdf.getDocument({data:new Uint8Array(await file.arrayBuffer())}).promise;
    const rows:unknown[][]=[];const text:string[]=[];
    for(let p=1;p<=doc.numPages;p++) {const page=await doc.getPage(p);const content=await page.getTextContent();const lines=new Map<number,{x:number;s:string}[]>();
      for(const item of content.items)if('str' in item){const y=Math.round(item.transform[5]/3)*3;const line=lines.get(y)||[];line.push({x:item.transform[4],s:item.str});lines.set(y,line);}
      for(const [,items] of [...lines].sort((a,b)=>b[0]-a[0])) {const line=items.sort((a,b)=>a.x-b.x).map(i=>i.s).join(' ').trim();if(!line)continue;text.push(line);
        const parts=line.match(/^(.*?)\s+(\(?-?(?:\d{1,3}(?:\.\d{3})*|\d+),\d{2}\)?(?:\s*[DC])?)\s*$/);
        if(parts){const code=parts[1].match(/^([\d.\-]+)\s+(.+)$/);rows.push([code?.[1]||String(rows.length+1),code?.[2]||parts[1],parts[2]]);}
      }
    }
    await doc.destroy();const content=text.join('\n');return {sheets:[{name:'Valores encontrados no PDF',rows:[['Código','Descrição','Valor'],...rows]}],text:content||'Não foi encontrado texto selecionável. Consulte o PDF original e preencha as contas manualmente, ou envie Excel.',detected:detectAasiPdf(content)};
  }
  if(!/\.(xlsx|xls|csv)$/i.test(file.name))throw Error('Selecione Excel, CSV ou PDF.');
  const XLSX=await import('xlsx');const book=XLSX.read(await file.arrayBuffer(),{type:'array',cellDates:true});
  const sheets=book.SheetNames.map(name=>({name,rows:XLSX.utils.sheet_to_json<unknown[]>(book.Sheets[name],{header:1,defval:'',blankrows:true})}));return {sheets,text:'',detected:detectAasi(sheets)};
}
const normalize=(s:string)=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
export function suggestCategory(name:string):Category {
  const n=normalize(name);
  if(/total|resultado|ativo circulante|passivo circulante|ativo total|passivo total/.test(n))return 'ignore';
  if(/salario|pessoal|folha|encargo|beneficio|ferias/.test(n))return 'personnel';
  if(/subvenc.*enviad/.test(n))return 'grant';
  if(/despesa.*administr|energia|telefone|viage|manutenc|aluguel/.test(n))return 'admin';
  if(/receita|dizimo|oferta|doac.*recebid/.test(n))return 'revenue';
  if(/despesa|gasto/.test(n))return 'expense';
  if(/caixa|banco|disponibilidade|aplicac.*financeir/.test(n))return 'cash';
  if(/a receber|adiantamento|imposto.*recuperar/.test(n))return 'receivable';
  if(/a pagar|fornecedor|imposto.*recolher/.test(n))return 'payable';
  if(/patrimonio|reserva/.test(n))return 'equity';
  if(/emprestimo|financiamento/.test(n))return 'liability';
  return 'ignore';
}
export type Mapping={code:number;name:number;value:number;budget:number;category:number;movement:number;due:number;mirror:number;expected:number};
export const defaultMapping:Mapping={code:0,name:1,value:2,budget:-1,category:-1,movement:-1,due:-1,mirror:-1,expected:-1};
export function mapAccounts(sheet:Sheet,header:number,map:Mapping):{accounts:Account[];skipped:number} {
  const accounts:Account[]=[];let skipped=0;
  const date=(v:unknown)=>v instanceof Date?v.toISOString().slice(0,10):/^\d{4}-\d{2}-\d{2}$/.test(String(v))?String(v):/^\d{2}\/\d{2}\/\d{4}$/.test(String(v))?String(v).split('/').reverse().join('-'):'';
  sheet.rows.slice(header+1).forEach((r,i)=>{if(!r.some(x=>String(x).trim()))return;const value=parseNumber(r[map.value]);const name=String(r[map.name]??'').trim();if(value===null||!name){skipped++;return;}
    const rawCategory=String(r[map.category]??'');const category=Object.hasOwn(categories,rawCategory)?rawCategory as Category:suggestCategory(name);
    accounts.push({code:String(r[map.code]||'linha-'+(header+i+2)).trim(),name,category,value,budget:map.budget<0?null:parseNumber(r[map.budget]),nature:/C\s*$/i.test(String(r[map.value]))?'C':/D\s*$/i.test(String(r[map.value]))?'D':'',expected:['D','C'].includes(String(r[map.expected]).toUpperCase())?String(r[map.expected]).toUpperCase() as 'D'|'C':'',movement:date(r[map.movement]),due:date(r[map.due]),mirror:String(r[map.mirror]??'')});
  });return {accounts,skipped};
}
