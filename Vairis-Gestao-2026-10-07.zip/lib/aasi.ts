import {parseNumber,ratio,type Account,type Category,type Balance} from './balance';
import type {Sheet} from './balance-import';
const norm=(v:unknown)=>String(v??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim().toUpperCase();
const groups:Record<string,Category>={A311:'revenue',A312:'revenue',A313:'revenue',A314:'revenue',A315:'revenue',A316:'revenue',A317:'expense',A318A:'revenue',A318B:'revenue',A319:'revenue',A321:'revenue',A411:'personnel',A412:'admin',A414:'expense',A419:'grant',A421:'expense'};
const account=(code:string,name:string,category:Category,value:number,budget:number|null=null):Account=>({code,name,category,value,budget,nature:'',expected:'',movement:'',due:'',mirror:''});
const limits={personnel:64,admin:19,variation:20,amount:20000,stale:6};
export function detectAasi(sheets:Sheet[]):Balance|null {
  const find=(name:string)=>sheets.find(s=>norm(s.name)===name)?.rows;
  const bp=find('BP'),dre=find('DRE'),month=find('DRE MES X ORC'),afe=find('AFE');if(!bp||!dre||!month)return null;
  if(norm(bp[7]?.[15])!=='TOTAL'||norm(dre[7]?.[14])!=='TOTAL'||norm(month[7]?.[12])!=='TOTAL')return null;
  const text=sheets.flatMap(s=>s.rows.slice(0,55).flat()).map(x=>String(x??'')).join(' ');
  const months=['JANEIRO','FEVEREIRO','MARCO','ABRIL','MAIO','JUNHO','JULHO','AGOSTO','SETEMBRO','OUTUBRO','NOVEMBRO','DEZEMBRO'];
  const date=norm(text).match(new RegExp('('+months.join('|')+')/(20\\d{2})'));if(!date)return null;
  const mm=months.indexOf(date[1])+1,year=date[2],period=`${year}-${String(mm).padStart(2,'0')}`;
  const code=text.match(/Entidade de C[aá]lculo:\s*(\d+)/i)?.[1];const entity=(String(bp[0]?.[0]||'Entidade AASI').trim())+(code?' · '+code:'');
  const byLabel=(rows:unknown[][],label:string)=>rows.find(r=>r.slice(0,3).some(v=>norm(v)===label));
  const value=(rows:unknown[][],label:string,col:number)=>parseNumber(byLabel(rows,label)?.[col]);
  const accounts:Account[]=[];
  for(const r of month){const c=String(r[1]??'').trim();if(groups[c]&&parseNumber(r[12])!==null)accounts.push(account(c,String(r[2]),groups[c],parseNumber(r[12])!,parseNumber(r[14])));}
  const stockGroups:Record<string,Category>={A111:'cash',A112:'cash',A113:'receivable',A114:'asset',A116:'asset',A117:'ignore',A121:'asset',A131:'asset',A132:'asset',A133:'asset',A213:'payable',A214:'liability',A215:'liability',A216:'liability',A217:'ignore',A221:'liability'};
  for(const r of bp){const c=String(r[1]??'').trim();if(stockGroups[c]&&parseNumber(r[15])!==null)accounts.push(account(c,String(r[2]),stockGroups[c],parseNumber(r[15])!));}
  const rev=value(month,'RECEITAS',12),sub=value(month,'SUBVENCOES RECEBIDAS LIQUIDAS',12),nonop=value(month,'RECEITAS NAO OPERACIONAIS',12),ex=value(month,'DESPESAS',12),nonex=value(month,'DESPESAS PATRIMONIAIS NAO OPERACIONAIS',12);
  const sum=(...v:(number|null)[])=>v.every(n=>n!==null)?v.reduce<number>((s,n)=>s+n!,0):null;
  const pc=value(bp,'PASSIVO CIRCULANTE',15),pnc=value(bp,'PASSIVO NAO CIRCULANTE',15);
  const metrics={revenue:sum(rev,sub,nonop),expense:sum(ex,nonex),personnel:parseNumber(month.find(r=>r[1]==='A411')?.[12]),admin:parseNumber(month.find(r=>r[1]==='A412')?.[12]),cash:sum(parseNumber(bp.find(r=>r[1]==='A111')?.[15]),parseNumber(bp.find(r=>r[1]==='A112')?.[15])),receivable:parseNumber(bp.find(r=>r[1]==='A113')?.[15]),payable:parseNumber(bp.find(r=>r[1]==='A213')?.[15]),currentAssets:value(bp,'ATIVO CIRCULANTE',15),currentLiabilities:pc,assets:value(bp,'TOTAL DO ATIVO',15),liabilities:sum(pc,pnc),equity:value(bp,'PATRIMONIO LIQUIDO',15),accumulatedResult:value(dre,'RESULTADO DO EXERCICIO',14)};
  const principal=parseNumber(dre.find(r=>r[1]==='A311')?.[14]);
  const personnelRatio=ratio(parseNumber(dre.find(r=>r[1]==='A411')?.[14]),principal),adminRatio=ratio(parseNumber(dre.find(r=>r[1]==='A412')?.[14]),principal);
  const reports:Balance[]=[];
  if(afe){const row=(label:string)=>byLabel(afe,label);const start=afe.findIndex(r=>norm(r[0]).includes('VALORES DOS INDICADORES ECONOMICOS DO MES'));const economic=afe.slice(start+1);const rows:Record<string,string>={A311:'DIZIMOS LIQUIDOS DE REPASSES',A312:'OFERTAS',A313:'DOACOES E CONTRIBUICOES RECEBIDAS',A314:'PRESTACAO DE SERVICOS',A315:'VENDAS DE MERCADORIAS, PROD. E SERVICOS',A316:'(-)DEDUCOES DE VENDAS',A317:'(-)CUSTOS DAS VENDAS',A318A:'RECEITAS FINANCEIRAS',A318B:'OUTRAS RECEITAS RECORRENTES',A319:'SUBVENCOES RECEBIDAS LIQUIDAS',A321:'RECEITAS NAO OPERACIONAIS',A411:'DESPESAS COM PESSOAL',A412:'ADMINISTRATIVAS E GERAIS',A414:'EDUCACAO, ASSISTENCIA E ORIENTACAO SOCIAL',A419:'SUBVENCOES, CONTRIBUICOES E DOACOES ENVIADAS',A421:'DESPESAS PATRIMONIAIS NAO OPERACIONAIS'};
    for(let m=1;m<mm;m++){const col=m+2;const rs:Account[]=[];for(const [c,label]of Object.entries(rows)){const r=byLabel(economic,label);const n=parseNumber(r?.[col]);if(r&&n!==null)rs.push(account(c,String(r[0]||r[1]),groups[c],n));}if(!rs.length)continue;const v=(l:string)=>parseNumber(byLabel(economic,l)?.[col]);reports.push({entity,period:`${year}-${String(m).padStart(2,'0')}`,basis:'monthly',flowComplete:false,accounts:rs,metrics:{revenue:sum(v('RECEITAS OPERACIONAIS'),v('SUBVENCOES RECEBIDAS LIQUIDAS'),v('RECEITAS NAO OPERACIONAIS')),expense:sum(v('DESPESAS OPERACIONAIS'),v('DESPESAS PATRIMONIAIS NAO OPERACIONAIS')),personnel:v('DESPESAS COM PESSOAL'),admin:v('ADMINISTRATIVAS E GERAIS'),cash:parseNumber(row('DISPONIVEL')?.[col])},limits});}
  }
  const annualAccounts:Account[]=[];
  for(const sheet of [sheets.find(s=>norm(s.name)==='ACAP'),sheets.find(s=>norm(s.name)==='ACRD')]) {let group='';for(const r of sheet?.rows||[]){const c=String(r[0]??'').trim();const g=c.match(/^(A\d{3}[AB]?)[\s-]/);if(g){group=g[1];continue;}if(!/^\d{7}$/.test(c)||parseNumber(r[5])===null)continue;const cat=groups[group]||(group==='A318'?'revenue':stockGroups[group])||(/^3/.test(c)?'revenue':/^4/.test(c)?'expense':'ignore');annualAccounts.push(account(c,String(r[1]),cat,parseNumber(r[5])!,sheet?.name==='ACRD'?parseNumber(r[6]):null));}}
  const merged=new Map<string,Account>();for(const a of annualAccounts){const old=merged.get(a.code);if(old){old.value+=a.value;old.budget=old.budget===null&&a.budget===null?null:(old.budget||0)+(a.budget||0);}else merged.set(a.code,{...a});}
  const flags:{description:string;value:number}[]=[];for(const r of find('PA')||[])if(Number(r[2])===1&&parseNumber(r[1])!==null)flags.push({description:String(r[0]),value:parseNumber(r[1])!});
  return {entity,period,basis:'monthly',flowComplete:false,accounts,metrics,limits,source:{format:'AASI',notes:['Valores mensais: DRE MÊS x ORÇ, coluna TOTAL, incluindo subvenções recebidas e itens não operacionais.','Patrimônio: BP, coluna TOTAL, com exclusões de interfundos do relatório.','Pessoal e administrativo: índices acumulados sobre dízimos líquidos de repasses (A311), conforme DRE/AFE.','Histórico mensal incorporado: AFE. Detalhe de contas ACAP/ACRD mantido separado; não é somado com os grupos.'],personnelRatio,adminRatio,principal,reports,annualAccounts:[...merged.values()],flags}};
}
export function detectAasiPdf(text:string):Balance|null {
  if(!norm(text).includes('ADMINISTRATIVO DENOMINACIONAL'))return null;
  const lines=text.split('\n'),bp:unknown[][]=Array.from({length:8},()=>[]),dre:unknown[][]=Array.from({length:8},()=>[]),month:unknown[][]=Array.from({length:8},()=>[]);
  const entity=lines.find(l=>norm(l).includes('ASSOCIACAO')||norm(l).includes('MISSAO'))||'Entidade AASI';
  for(const r of [bp,dre,month])r[0]=[entity];bp[7][15]='TOTAL';dre[7][14]='TOTAL';month[7][12]='TOTAL';
  let section='';
  for(const line of lines){const n=norm(line);if(n==='BALANCO PATRIMONIAL')section='BP';else if(n.includes('DEMONSTRATIVO DE RESULTADOS - TODOS FUNDOS'))section='DRE';else if(n.includes('RESULTADOS DO MES COMPARADO'))section='MONTH';else if(n.includes('RESULTADOS COMPARADO COM ORCAMENTO')||n.includes('MUTACOES FINANCEIRAS'))section='';
    if(!section)continue;const matches=[...line.matchAll(/\(?-?(?:\d{1,3}(?:\.\d{3})*|\d+),\d{2}\)?/g)];const target=section==='BP'?bp:section==='DRE'?dre:month;const index=section==='BP'?5:section==='DRE'?4:3;
    if(matches.length<=index)continue;let label=line.slice(0,matches[0].index).trim();const code=label.match(/^(A\d{3}[AB]?)/)?.[1];const row:unknown[]=[];
    if(code){row[1]=code;row[2]=label.slice(code.length).trim();}else row[0]=label;
    row[section==='BP'?15:section==='DRE'?14:12]=parseNumber(matches[index][0]);if(section==='MONTH'&&matches.length>4)row[14]=parseNumber(matches[4][0]);target.push(row);
  }
  const result=detectAasi([{name:'CAPA',rows:[[text.slice(0,4000)]]},{name:'BP',rows:bp},{name:'DRE',rows:dre},{name:'DRE MÊS x ORÇ',rows:month}]);
  if(!result||result.metrics.assets===null||result.metrics.accumulatedResult===null||result.metrics.revenue===null)return null;
  const difference=result.metrics.assets!-result.metrics.liabilities!-result.metrics.equity!;
  if(Math.abs(difference)>0.01)result.source!.flags.push({description:'Diferença entre ativo e passivo mais patrimônio líquido (BP)',value:Math.round(difference*100)/100});
  result.source!.notes=['PDF AASI: totais da BP, DRE e DRE do mês reconhecidos. Confira os valores no documento original.','Pessoal e administrativo: índices acumulados sobre dízimos líquidos (A311).','O histórico AFE arredondado do PDF não é importado automaticamente. Use Excel para incorporar os valores mensais exatos.'];
  return result;
}
