import { analyze, money, type Balance } from './balance';

export function summaryData(balance: Balance, history: Balance[]) {
  const report = analyze(balance, history);
  const [year, month] = balance.period.split('-').map(Number);
  const months = ['JANEIRO','FEVEREIRO','MARÇO','ABRIL','MAIO','JUNHO','JULHO','AGOSTO','SETEMBRO','OUTUBRO','NOVEMBRO','DEZEMBRO'];
  const grant = report.differences.filter(a => a.category === 'grant' && a.delta !== null && a.delta > 0).sort((a,b) => b.delta! - a.delta!)[0];
  const highlight = report.result === null ? 'Resultado mensal não informado. Confira os totais e a competência do balanço antes de divulgar.' :
    `O mês encerrou com ${report.result >= 0 ? 'resultado positivo' : 'déficit'} de ${money(report.result)}.` +
    (grant ? ` As subvenções enviadas somaram ${money(grant.current)}, aumento de ${money(grant.delta)} em relação ao mês anterior.` :
      report.previousResult !== null ? ` No mês anterior, o resultado foi de ${money(report.previousResult)}.` : '') +
    ' Revise as movimentações e os documentos de suporte para contextualizar o período.';
  return { entity: balance.entity.replace(/\s*·\s*\d+$/, ''), period: balance.period, title: months[month-1]+'/'+year,
    cash: report.m.cash, accumulated: report.accumulated, result: report.result,
    personnel: report.personnel === null ? null : report.personnel * 100,
    admin: report.admin === null ? null : report.admin * 100,
    personnelLimit: balance.limits.personnel, adminLimit: balance.limits.admin,
    basis: balance.source ? 'Índices acumulados sobre dízimos líquidos' : 'Índices do mês sobre a receita', highlight };
}
export type FinancialSummary = ReturnType<typeof summaryData>;

// The exported image is drawn from data, so text and numbers remain exact and selectable inputs never execute markup.
export function drawFinancialSummary(canvas: HTMLCanvasElement, data: FinancialSummary, highlight: string) {
  canvas.width = 1600; canvas.height = 900;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Seu navegador não conseguiu gerar a imagem. Tente no Chrome ou Edge.');
  const c = ctx, gold = '#e8d27c', cyan = '#49d8d5', white = '#f6f8fc';
  const bg = c.createLinearGradient(0,0,1600,900); bg.addColorStop(0,'#041e39'); bg.addColorStop(.5,'#05223d'); bg.addColorStop(1,'#00152c');
  c.fillStyle=bg; c.fillRect(0,0,1600,900);
  function line(x:number,y:number,x2:number,y2:number,color=gold,width=2) { c.beginPath();c.moveTo(x,y);c.lineTo(x2,y2);c.strokeStyle=color;c.lineWidth=width;c.stroke(); }
  function box(x:number,y:number,w:number,h:number,color:string,r=17) { c.beginPath();c.roundRect(x,y,w,h,r);c.fillStyle='#02182bb3';c.fill();c.strokeStyle=color;c.lineWidth=2;c.stroke(); }
  function text(t:string,x:number,y:number,size:number,color=white,weight=400,align:CanvasTextAlign='left',max=1480) {
    c.textAlign=align;c.textBaseline='middle';c.fillStyle=color;
    let s=size;do { c.font=`${weight} ${s}px Arial, sans-serif`;if(c.measureText(t).width<=max)break;s--; } while(s>10);
    c.fillText(t,x,y);
  }
  function wrap(t:string,w:number,size:number) {
    c.font=`400 ${size}px Arial, sans-serif`;const lines:string[]=[];
    for (const paragraph of t.split('\n')) { let current='';for(const word of paragraph.split(/\s+/).filter(Boolean)) {
      // Break very long tokens as well as normal words, preventing clipping on pasted text.
      let token='';for(const char of word){if(c.measureText(token+char).width>w){if(current){lines.push(current);current='';}lines.push(token);token=char;}else token+=char;}
      if(c.measureText(current+(current?' ':'')+token).width>w){lines.push(current);current=token;}else current+=(current?' ':'')+token;
    }lines.push(current); }return lines;
  }
  function paragraph(t:string,x:number,y:number,w:number,h:number) {
    let size=23,lines=wrap(t,w,size);while(lines.length*size*1.3>h&&size>12){size--;lines=wrap(t,w,size);}
    lines.forEach((t,i)=>text(t,x,y+i*size*1.3,size));
  }
  function icon(kind:string,x:number,y:number,r=58) {
    const fill=c.createRadialGradient(x-20,y-25,2,x,y,r);fill.addColorStop(0,'#0c6470');fill.addColorStop(1,'#03253c');
    c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fillStyle=fill;c.fill();c.strokeStyle=kind==='people'||kind==='pie'?cyan:gold;c.lineWidth=2.5;c.stroke();
    c.save();c.translate(x,y);c.strokeStyle=gold;c.lineWidth=3;c.lineJoin='round';c.lineCap='round';
    const path=(points:number[][])=>{c.beginPath();points.forEach(([a,b],i)=>i?c.lineTo(a,b):c.moveTo(a,b));c.stroke();};
    if(kind==='wallet'){c.beginPath();c.roundRect(-30,-16,61,45,5);c.stroke();path([[-26,-16],[16,-30],[23,-16]]);c.beginPath();c.roundRect(7,-3,29,18,4);c.stroke();c.beginPath();c.arc(18,6,2,0,Math.PI*2);c.stroke();}
    if(kind==='chart'){for(let i=0;i<3;i++)c.strokeRect(-29+i*22,24-i*11,11,12+i*11);path([[-30,1],[-15,-4],[-1,-18],[13,-10],[29,-31],[29,-20]]);path([[17,-31],[29,-31]]);}
    if(kind==='calendar'){c.beginPath();c.roundRect(-31,-26,62,56,4);c.stroke();line(-31,-10,31,-10);for(const a of [-17,17]){path([[a,-33],[a,-20]]);}for(let i=0;i<6;i++)c.strokeRect(-20+(i%3)*16,1+Math.floor(i/3)*15,8,7);}
    if(kind==='people'){for(const [a,b] of [[-22,0],[0,-10],[22,0]]){c.beginPath();c.arc(a,b-12,7,0,Math.PI*2);c.stroke();c.beginPath();c.moveTo(a-10,b+20);c.lineTo(a-10,b+8);c.quadraticCurveTo(a,b-5,a+10,b+8);c.lineTo(a+10,b+20);c.stroke();}}
    if(kind==='pie'){c.beginPath();c.arc(-4,4,30,-Math.PI/2,0,false);c.lineTo(-4,4);c.closePath();c.stroke();c.beginPath();c.arc(-4,4,30,0,Math.PI*1.5,false);c.lineTo(-4,4);c.closePath();c.stroke();path([[3,-34],[3,-4],[34,-4]]);}
    if(kind==='document'){path([[-23,-31],[14,-31],[25,-20],[25,31],[-23,31],[-23,-31]]);path([[14,-31],[14,-20],[25,-20]]);for(let j=0;j<4;j++)path([[-12,-10+j*11],[13,-10+j*11]]);}
    c.restore();
  }
  // Decorative arcs and financial chart retain the reference's horizontal composition.
  for(let i=0;i<5;i++){c.beginPath();c.arc(-14,-26,100+i*22,0,Math.PI*2);c.strokeStyle=i%2?gold+'66':cyan+'66';c.lineWidth=1;c.stroke();}
  c.save();c.globalAlpha=.18;for(let i=0;i<8;i++){c.fillStyle='#2b88b1';c.fillRect(1350+i*30,184-i*15,20,15+i*15);}c.restore();
  c.beginPath();c.moveTo(1310,187);c.bezierCurveTo(1490,174,1520,126,1580,48);c.strokeStyle='#25bed177';c.lineWidth=2;c.stroke();
  for(let i=0;i<14;i++){c.beginPath();c.moveTo(0,568+i*12);c.bezierCurveTo(120,580+i*12,170,740+i*12,305,900);c.strokeStyle='#1e91b322';c.lineWidth=1;c.stroke();}
  text(data.entity,800,40,23,white,400,'center',960);line(332,41,481,41);line(1100,41,1250,41);
  const title='RESUMO FINANCEIRO — '+data.title;
  text(title,800,103,64,white,700,'center',1440);
  // Paint the date in gold within the centered title, with the exact same fitted font.
  const titleWidth=c.measureText(title).width, prefixWidth=c.measureText('RESUMO FINANCEIRO — ').width;
  c.textAlign='left';c.fillStyle=gold;c.fillText(data.title,800-titleWidth/2+prefixWidth,103);
  text('P L A N E J A M E N T O   H O J E,   M A I S   M I S S Ã O   A M A N H Ã',800,152,17,white,400,'center',1040);
  line(330,152,497,152);line(1103,152,1270,152);
  const xs=[62,568,1059],ws=[479,465,479],labels=['Total disponível','Resultado acumulado','Resultado do mês'],values=[data.cash,data.accumulated,data.result],icons=['wallet','chart','calendar'];
  xs.forEach((x,i)=>{const w=ws[i];box(x,189,w,245,gold);icon(icons[i],x+w/2,235);text(labels[i],x+w/2,319,29,white,700,'center',w-30);line(x+w/2-34,343,x+w/2+34,343,cyan);text(money(values[i]),x+w/2,382,52,cyan,700,'center',w-35);});
  function gauge(x:number,label:string,value:number|null,limit:number,kind:string) {
    box(x,454,727,206,cyan);icon(kind,x+86,522,51);text(label,x+171,491,28,white,700,'left',310);
    text(value===null?'Não informado':value.toLocaleString('pt-BR',{minimumFractionDigits:2,maximumFractionDigits:2})+'%',x+171,547,value===null?32:62,cyan,700,'left',305);
    line(x+489,487,x+489,558);text('Ideal: até '+limit.toLocaleString('pt-BR')+'%',x+528,529,24,gold,400,'left',181);
    const start=x+34,width=662,scale=Math.max(kind==='pie'?23:80,limit*1.2,value??0),marker=start+width*limit/scale;
    box(start,589,width,28,'#2a4d62',14);
    if(value!==null&&value>0){const gradient=c.createLinearGradient(start,0,start+width,0);gradient.addColorStop(0,'#249fa4');gradient.addColorStop(1,cyan);c.fillStyle=gradient;c.beginPath();c.roundRect(start,589,Math.min(width,width*value/scale),28,14);c.fill();}
    c.save();c.setLineDash([5,5]);line(marker,561,marker,620,gold,3);c.restore();text(limit.toLocaleString('pt-BR')+'%',marker,640,22,gold,700,'center',100);
  }
  gauge(62,'Custo com pessoal',data.personnel,data.personnelLimit,'people');gauge(813,'Despesas administrativas',data.admin,data.adminLimit,'pie');
  box(62,675,1476,147,gold);icon('document',177,751,57);line(277,696,277,802);
  text('DESTAQUE DO PERÍODO',325,705,25,gold,700);paragraph(highlight||'Sem destaque informado.',325,743,1160,65);
  text('R E C U R S O S   Q U E   S E R V E M   V I D A S',64,860,12,'#329bb1');
  line(367,857,1167,857,'#266a83',1);text('I G R E J A   |   C O M U N I D A D E   |   F U T U R O',1540,860,12,'#329bb1',400,'right',360);
  text(data.basis,800,883,12,'#7eabb9',400,'center',800);
}
