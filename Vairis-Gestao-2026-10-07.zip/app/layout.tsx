import type { Metadata } from "next";
import { headers } from "next/headers";
import "./globals.css";

export async function generateMetadata(): Promise<Metadata> {
  const incoming = await headers();
  const host = incoming.get("x-forwarded-host") || incoming.get("host") || "localhost:3000";
  const protocol = incoming.get("x-forwarded-proto") || (host.includes("localhost") ? "http" : "https");
  const base = new URL(`${protocol}://${host}`);
  const title = "Vairis Gestão | Meu espaço de trabalho";
  const description = "Seu sistema pessoal para documentos, conciliações e extração de relatórios.";
  return {
    metadataBase: base, icons: { icon: "/vairis-icon.svg", apple: "/icon-192.png" }, appleWebApp: { capable: true, title: "Vairis Gestão", statusBarStyle: "default" },
    title,
    description,
    openGraph: { title, description, images: [{ url: new URL("/og.png", base).toString(), width: 2048, height: 1152 }] },
    twitter: { card: "summary_large_image", title, description, images: [new URL("/og.png", base).toString()] },
  };
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR"><head><link rel="manifest" href="/manifest.webmanifest" crossOrigin="use-credentials" /><meta name="theme-color" content="#061c34" /></head><body>{children}</body></html>;
}


