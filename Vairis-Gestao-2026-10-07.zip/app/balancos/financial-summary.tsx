'use client';
import { useEffect, useMemo, useRef, useState } from 'react';
import type { Balance } from '../../lib/balance';
import { drawFinancialSummary, summaryData } from '../../lib/financial-summary';

export default function FinancialSummary({balance,history}:{balance:Balance;history:Balance[]}) {
  const data=useMemo(()=>summaryData(balance,history),[balance,history]);
  const dialog=useRef<HTMLDialogElement>(null),canvas=useRef<HTMLCanvasElement>(null);
  const [opened,setOpened]=useState(false),[highlight,setHighlight]=useState(''),[error,setError]=useState(''),[downloading,setDownloading]=useState(false);
  useEffect(()=>{if(opened&&canvas.current){try{drawFinancialSummary(canvas.current,data,highlight);setError('');}catch(e){setError((e as Error).message);}}},[opened,data,highlight]);
  function open(){setHighlight(data.highlight);setOpened(true);setError('');dialog.current?.showModal();}
  function close(){dialog.current?.close();setOpened(false);}
  function download(){if(!canvas.current)return;setDownloading(true);canvas.current.toBlob(blob=>{setDownloading(false);if(!blob){setError('Não foi possível baixar a imagem. Tente novamente.');return;}const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='resumo-financeiro-'+data.period+'.png';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);},'image/png');}
  return <><button className="v-button" onClick={open}>Gerar resumo financeiro</button><dialog ref={dialog} className="b-summary-dialog" aria-labelledby="financial-summary-title" onCancel={()=>setOpened(false)}>
    <div className="v-install-head"><h2 id="financial-summary-title">Resumo financeiro em imagem</h2><button className="v-install-close" aria-label="Fechar resumo financeiro" onClick={close}>×</button></div>
    {opened&&<div className="b-summary-body"><p>Modelo do resumo enviado · {data.title}. Os valores acompanham o balanço selecionado.</p><canvas ref={canvas} className="b-summary-canvas" role="img" aria-label={'Resumo financeiro de '+data.entity+' — '+data.title}/>
      <label htmlFor="financial-highlight">Destaque do período — revise antes de divulgar</label><textarea id="financial-highlight" maxLength={600} rows={3} value={highlight} onChange={e=>setHighlight(e.target.value)}/>
      <p className="v-helper">{highlight.length}/600 caracteres · {data.basis}. Dados ausentes aparecem como “Não informado”. O destaque é uma sugestão baseada nos valores; acrescente o contexto das movimentações.</p>
      {error&&<p role="alert" className="b-error">{error}</p>}<div className="b-actions"><button className="v-text-button" onClick={()=>setHighlight(data.highlight)}>Restaurar destaque sugerido</button><button className="v-button" disabled={!!error||downloading} onClick={download}>{downloading?'Preparando…':'Baixar imagem PNG'}</button></div>
    </div>}
  </dialog></>;
}
