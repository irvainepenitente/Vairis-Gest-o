import { requireChatGPTUser } from '../chatgpt-auth';
import BalanceWorkspace from './workspace';
export const dynamic='force-dynamic';
export default async function Page(){const user=await requireChatGPTUser('/balancos');return <BalanceWorkspace email={user.email}/>;}
