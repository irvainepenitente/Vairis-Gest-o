"use client";
import { useEffect, useRef, useState } from 'react';
import * as XLSX from 'xlsx';
import AccountControls from './account-controls';
import MainNavigation from './main-navigation';
import EventosApso from './eventos-apso';
type RecordFile = { id: string; name: string; size: number; created: string; kind: string; records: number };
type Extraction = { columns: string[]; rows: Record<string, unknown>[]; text?: string };
function download(value: Blob, name: string) { const u = URL.createObjectURL(value); const a = document.createElement('a'); a.href = u; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(u), 1000); }
async function extract(file: File): Promise<Extraction> {
  if (/\.pdf$/i.test(file.name)) {
    const pdf = await import('pdfjs-dist'); pdf.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.mjs';
    const doc = await pdf.getDocument({ data: new Uint8Array(await file.arrayBuffer()) }).promise;
    const rows: Record<string, unknown>[] = [];
    for (let n = 1; n <= doc.numPages; n++) { const page = await doc.getPage(n); const content = await page.getTextContent(); const lines = new Map<number, { x: number; text: string }[]>();
      for (const item of content.items) if ('str' in item) { const y = Math.round(item.transform[5] / 3) * 3; const line = lines.get(y) || []; line.push({ x: item.transform[4], text: item.str }); lines.set(y, line); }
      for (const [, line] of [...lines].sort((a,b) => b[0]-a[0])) { const text = line.sort((a,b) => a.x-b.x).map(i => i.text).join(' ').trim(); if(text) rows.push({ Página: n, Texto: text }); }
    }
    if (!rows.length) throw new Error('Este PDF não contém texto selecionável. Envie uma versão com texto; leitura de imagens ainda não está disponível.');
    return { columns: ['Página','Texto'], rows };
  }
  const book = XLSX.read(await file.arrayBuffer(), { type: 'array' }); const sheet = book.Sheets[book.SheetNames[0]];
  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: '' });
  if (!rows.length) throw new Error('A primeira aba não tem dados para extrair.');
  return { columns: Object.keys(rows[0]), rows };
}
export default function Workspace({ email }: { email: string }) {
  const [view,setView] = useState('inicio'); const [files,setFiles] = useState<RecordFile[]>([]);
  const [busy,setBusy] = useState(false); const [message,setMessage] = useState(''); const [drag,setDrag] = useState(false);
  const [preview,setPreview] = useState<{ name:string; data:Extraction } | null>(null);
  const picker = useRef<HTMLInputElement>(null);
  async function refresh() { const r = await fetch('/api/documents'); if (!r.ok) throw new Error('Não foi possível carregar seus documentos. Tente novamente.'); setFiles(await r.json()); }
  useEffect(() => { const requested = new URL(window.location.href).searchParams.get('view'); if (requested && ['inicio','documentos','relatorios','fluxo-caixa','avisos-arm','eventos-apso','integracoes'].includes(requested)) setView(requested); refresh().catch(e => setMessage(e instanceof Error ? e.message : 'Não foi possível carregar os documentos.')); },[]);
  async function upload(list: FileList | null) { if (!list || busy) return; setBusy(true); setMessage('');
    try { for (const file of Array.from(list)) {
      if (!/\.(pdf|xlsx|xls|csv)$/i.test(file.name)) throw new Error('Use PDF, Excel ou CSV.');
      if (file.size > 20*1024*1024) throw new Error('O limite é 20 MB por arquivo.');
      const data = await extract(file); const body = new FormData(); body.append('file',file); body.append('extraction',JSON.stringify(data));
      const r = await fetch('/api/documents',{method:'POST',body}); if (!r.ok) { const e = await r.json() as { error?: string }; throw new Error(e.error || 'Não foi possível salvar o documento.'); }
      setPreview({ name:file.name, data }); await refresh();
    } setMessage('Documento salvo e dados extraídos. Revise a prévia antes de usar o relatório.'); }
    catch(e) { setMessage(e instanceof Error ? e.message : 'Falha ao processar o arquivo.'); } finally { setBusy(false); if(picker.current) picker.current.value=''; }
  }
  async function open(file:RecordFile) { setMessage(''); try { const r = await fetch('/api/documents/'+file.id+'?report=1'); if(!r.ok) throw new Error('Não foi possível abrir o relatório.'); setPreview({name:file.name,data:await r.json()}); } catch(e) { setMessage((e as Error).message); } }
  function exportReport() { if(!preview) return; const sheet = XLSX.utils.json_to_sheet(preview.data.rows); download(new Blob(['\uFEFF'+XLSX.utils.sheet_to_csv(sheet,{FS:';'})],{type:'text/csv;charset=utf-8'}),preview.name.replace(/\.[^.]+$/,'')+'-extraido.csv'); }
  const nav = [['inicio','◫','Visão geral'],['documentos','▤','Documentos'],['relatorios','▥','Relatórios'],['fluxo-caixa','◇','Fluxo de Caixa'],['avisos-arm','◇','Avisos ARM'],['eventos-apso','◇','Eventos APSo'],['integracoes','◇','Integrações']];
  return <div className="v-app v-horizontal-app"><div className="v-main"><header className="v-header v-horizontal-header"><a href="/" className="v-brand"><span className="vairis-mark">V</span><span>Vairis <b>Gestão</b></span></a><div className="v-header-account"><span className="v-account" title={email}>{email}</span><AccountControls disabled={busy} /></div></header><section className="v-cover v-full-cover" aria-label="Capa Vairis Gestão"><img src="/vairis-capa.png" alt="Vairis Gestão — Contabilidade, Finanças e Gestão" width="2048" height="683" fetchPriority="high" /></section><MainNavigation current={view} onNavigate={setView} /><main className="v-content">
  <div className="v-heading"><div><p className="overline">VAIRIS GESTÃO · PESSOAL</p><h1>{view==='inicio'?'Tudo pronto para trabalhar.':nav.find(n=>n[0]===view)?.[2]}</h1><p>{view==='fluxo-caixa'?'Seu espaço para acompanhar entradas, saídas e saldos.':view==='eventos-apso'?'Seu espaço para os eventos da APSo.':view==='avisos-arm'?'Comunicados do ARM.':view==='integracoes'?'Seu sistema, preparado para crescer com você.':'Organize seus documentos e transforme dados em decisões.'}</p></div></div>
  {message && <div className="v-notice" role="status">{message}</div>}
  {view==='inicio' && <><section className="v-stats"><article><span>DOCUMENTOS SALVOS</span><strong>{files.length.toString().padStart(2,'0')}</strong><small>Na sua central de arquivos</small></article><article><span>RELATÓRIOS EXTRAÍDOS</span><strong>{files.length.toString().padStart(2,'0')}</strong><small>Disponíveis para revisão</small></article><article><span>SEU MÓDULO ATIVO</span><strong className="v-stat-label">Conciliação ACMS</strong><small>Entidades 112111 e 112192</small></article></section><div className="v-section-heading"><h2>O que vamos fazer hoje?</h2><span>Seu fluxo de trabalho</span></div><section className="v-modules"><a href="/conciliacao" className="v-module v-acms"><span className="v-module-icon">⇄</span><span className="v-pill">DISPONÍVEL</span><h2>Conciliação ACMS</h2><p>Compare os três relatórios e identifique as correções por igreja.</p><strong>Abrir conciliação</strong></a><button onClick={()=>setView('relatorios')} className="v-module"><span className="v-module-icon">▥</span><h2>Extração de relatórios</h2><p>Extraia tabelas de planilhas e texto de PDFs. Revise e baixe em CSV.</p><strong>Extrair dados</strong></button></section></>}
  {view!=='integracoes' && view!=='avisos-arm' && view!=='fluxo-caixa' && view!=='eventos-apso' && <><section className="v-drop-section"><div className="v-section-heading"><h2>{view==='relatorios'?'Extrair um novo relatório':'Central de documentos'}</h2><span>PDF · Excel · CSV</span></div><div className={'v-drop '+(drag?'drag':'')} onDragOver={e=>{e.preventDefault();setDrag(true);}} onDragLeave={()=>setDrag(false)} onDrop={e=>{e.preventDefault();setDrag(false);upload(e.dataTransfer.files);}}><span className="v-drop-icon">▤</span><div><h3>{busy?'Processando seus documentos…':'Arraste seus documentos aqui'}</h3><p>Ou selecione arquivos do computador. Até 20 MB por arquivo.</p></div><button disabled={busy} className="v-button" onClick={()=>picker.current?.click()}>{busy?'Processando…':'Selecionar arquivos'}</button><input hidden ref={picker} multiple type="file" accept=".pdf,.xlsx,.xls,.csv" onChange={e=>upload(e.target.files)} /></div><p className="v-helper">Os documentos ficam salvos no seu espaço privado. PDFs precisam conter texto selecionável; a extração de Excel usa a primeira aba.</p></section>
  <div className="v-section-heading"><h2>{view==='relatorios'?'Relatórios disponíveis':'Documentos recentes'}</h2><span>{files.length} arquivo(s)</span></div><div className="v-files">{!files.length?<div className="v-empty"><b>Seu primeiro documento começa aqui.</b><p>Envie um arquivo para salvar, extrair e revisar os dados.</p></div>:<div className="v-file-scroll"><table><thead><tr><th>Documento</th><th>Enviado em</th><th>Registros</th><th>Ações</th></tr></thead><tbody>{files.map(f=><tr key={f.id}><td><span className="v-file-type">{f.kind}</span><b>{f.name}</b><small>{(f.size/1024).toFixed(0)} KB</small></td><td>{new Date(f.created).toLocaleDateString('pt-BR')}</td><td>{f.records}</td><td><button className="v-text-button" onClick={()=>open(f)}>Ver extração</button><a className="v-text-button" href={'/api/documents/'+f.id}>Baixar original</a></td></tr>)}</tbody></table></div>}</div>
  {preview && <section className="v-preview"><div className="v-section-heading"><div><p className="overline">PRÉVIA DA EXTRAÇÃO</p><h2>{preview.name}</h2></div><div className="v-preview-actions"><button className="v-button" onClick={exportReport}>Baixar CSV</button><button className="v-text-button" onClick={()=>setPreview(null)}>Fechar</button></div></div><p className="v-helper">{preview.data.rows.length} registros extraídos. Exibindo até 30 linhas para conferência.</p><div className="v-file-scroll"><table><thead><tr>{preview.data.columns.map(c=><th key={c}>{c}</th>)}</tr></thead><tbody>{preview.data.rows.slice(0,30).map((r,i)=><tr key={i}>{preview.data.columns.map(c=><td key={c}>{String(r[c]??'')}</td>)}</tr>)}</tbody></table></div></section>}</>}
  {view==='avisos-arm' && <section className="v-files" aria-label="Avisos ARM"><div className="v-empty"><b>Nenhum aviso publicado.</b><p>Os avisos ARM serão exibidos aqui.</p></div></section>}
  {view==='fluxo-caixa' && <section className="v-files" aria-label="Fluxo de Caixa"><div className="v-empty"><b>Fluxo de Caixa</b><p>Este espaço está reservado. Vamos configurar as informações e análises na próxima etapa.</p></div></section>}
    {view==='eventos-apso' && <EventosApso/>}
    {view==='integracoes' && <section className="v-integrations"><article><span className="v-module-icon">◌</span><span className="v-pill muted">FUTURO</span><h2>Chat particular</h2><p>Um espaço para conversar sobre seus documentos e seu trabalho.</p><small>A integração será configurada quando você escolher seu serviço de chat.</small></article><article><span className="v-module-icon">▱</span><span className="v-pill muted">FUTURO</span><h2>Banco particular</h2><p>Conecte suas próprias fontes de dados ao Vairis Gestão.</p><small>Seus documentos já são salvos neste sistema. A conexão com um banco externo será uma próxima etapa.</small></article></section>}
  <footer className="v-footer"><span>Vairis Gestão</span><p>Seu sistema pessoal de trabalho.</p><small>Espaço privado</small></footer></main></div></div>;
}





