"use client";

import { useMemo, useRef, useState } from "react";
import * as XLSX from "xlsx";
import AccountControls from "../account-controls";
import MainNavigation from "../main-navigation";

type Kind = "receber" | "pagar" | "acms";
type DataRow = Record<string, string | number | boolean | null>;
type FileData = { name: string; columns: string[]; rows: DataRow[] };
type Mapping = { key: string; balance: string };
type ResultRow = {
  key: string;
  name: string;
  entity111: number;
  entity192: number;
  acms: number;
  adjust111: number;
  adjust192: number;
  ok: boolean;
};

const labels: Record<Kind, { eyebrow: string; title: string; hint: string }> = {
  receber: { eyebrow: "ENTIDADE", title: "112111", hint: "Contas das igrejas a receber" },
  pagar: { eyebrow: "ENTIDADE", title: "112192", hint: "Contas das igrejas a pagar" },
  acms: { eyebrow: "RELATÓRIO", title: "ACMS", hint: "Saldo de referência do mês" },
};

const money = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" });

function normalize(value: unknown) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "");
}

function canonicalKey(value: unknown) {
  const raw = String(value ?? "").trim();
  if (/^0+\d+$/.test(raw)) return raw.replace(/^0+/, "") || "0";
  return normalize(raw);
}

function normalizeChurchCode(kind: Kind, value: unknown) {
  const digits = String(value ?? "").replace(/\D/g, "");
  if (!digits) return canonicalKey(value);
  let code = digits;
  if (kind === "pagar" && code.endsWith("24")) code = code.slice(0, -2);
  if (kind === "receber" && /^2\d{3}$/.test(code)) code = code.slice(1);
  return code.replace(/^0+/, "") || "0";
}

function toNumber(value: unknown) {
  if (typeof value === "number") return Number.isFinite(value) ? value : 0;
  let raw = String(value ?? "").trim();
  if (!raw) return 0;
  const negative = /^\(.*\)$/.test(raw) || raw.endsWith("-");
  raw = raw.replace(/[R$%()\s-]/g, "");
  if (raw.includes(",")) raw = raw.replace(/\./g, "").replace(",", ".");
  else if ((raw.match(/\./g) || []).length > 1) raw = raw.replace(/\./g, "");
  const parsed = Number(raw);
  return Number.isFinite(parsed) ? (negative ? -Math.abs(parsed) : parsed) : 0;
}

function detectColumn(columns: string[], patterns: RegExp[], fallback = "") {
  return columns.find((column) => patterns.some((pattern) => pattern.test(normalize(column)))) || fallback;
}

function suggestMapping(kind: Kind, columns: string[]): Mapping {
  const key = detectColumn(columns, [/igreja/, /entidade/, /codig/, /conta/, /unidade/, /estabelecimento/], columns[0] || "");
  const balance = detectColumn(columns, [/saldofinal/, /saldoatual/, /^saldo$/, /valor/, /total/], columns[1] || columns[0] || "");
  return { key, balance };
}

async function pdfLines(file: File) {
  const pdfjs = await import("pdfjs-dist");
  pdfjs.GlobalWorkerOptions.workerSrc = "/pdf.worker.min.mjs";
  const document = await pdfjs.getDocument({ data: new Uint8Array(await file.arrayBuffer()) }).promise;
  const lines: string[] = [];
  for (let pageNumber = 1; pageNumber <= document.numPages; pageNumber += 1) {
    const page = await document.getPage(pageNumber);
    const content = await page.getTextContent();
    const items = content.items
      .filter((item) => "str" in item && Boolean(item.str.trim()))
      .map((item) => {
        const textItem = item as { str: string; transform: number[] };
        return { text: textItem.str.trim(), x: textItem.transform[4], y: textItem.transform[5] };
      })
      .sort((a, b) => Math.abs(b.y - a.y) > 2 ? b.y - a.y : a.x - b.x);
    const grouped: { y: number; parts: { x: number; text: string }[] }[] = [];
    items.forEach((item) => {
      let line = grouped.find((candidate) => Math.abs(candidate.y - item.y) <= 2);
      if (!line) { line = { y: item.y, parts: [] }; grouped.push(line); }
      line.parts.push({ x: item.x, text: item.text });
    });
    grouped.sort((a, b) => b.y - a.y).forEach((line) => lines.push(line.parts.sort((a, b) => a.x - b.x).map((part) => part.text).join(" ").replace(/\s+/g, " ").trim()));
  }
  return lines;
}

async function parsePdf(kind: Kind, file: File): Promise<FileData> {
  const lines = await pdfLines(file);
  const rows: DataRow[] = [];
  if (kind === "acms") {
    lines.forEach((line) => {
      const match = line.match(/^(\d+)\s+(.+?)\s+Conta Corrente.*?\s(-?[\d.]+,\d{2}|-)\s*$/i);
      if (match) rows.push({ "Código da igreja": match[1], Igreja: match[2], "Saldo final": toNumber(match[3]) });
    });
  } else if (kind === "receber") {
    lines.forEach((line) => {
      const match = line.match(/^(2\d{3})\s+(.+?)\s+.*?([\d.]+,\d{2})\s+([DC])$/i);
      if (match) rows.push({ "Código da igreja": match[1], Igreja: match[2], "Saldo final": toNumber(match[3]) * (match[4].toUpperCase() === "D" ? -1 : 1) });
    });
  } else {
    let department = "";
    let church = "";
    lines.forEach((line) => {
      const dept = line.match(/^Departamento:\s+(\d+)\s+(.+)$/i);
      if (dept && dept[1].endsWith("24")) { department = dept[1]; church = dept[2]; return; }
      const match = line.match(/^112111\s+.+?([\d.]+,\d{2})\s+([DC])$/i);
      if (match && department) rows.push({ "Código da igreja": department, Igreja: church, "Saldo final": toNumber(match[1]) * (match[2].toUpperCase() === "D" ? 1 : -1) });
    });
  }
  if (!rows.length) throw new Error("não reconheci o formato deste PDF. Verifique se escolheu o relatório correto.");
  return { name: file.name, columns: ["Código da igreja", "Igreja", "Saldo final"], rows };
}

async function parseSpreadsheet(file: File): Promise<FileData> {
  const workbook = XLSX.read(await file.arrayBuffer(), { type: "array", cellDates: false });
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  const grid = XLSX.utils.sheet_to_json<(string | number | boolean | null)[]>(sheet, { header: 1, defval: null, raw: true });
  if (!grid.length) throw new Error("A primeira aba está vazia.");

  const keywords = /(igreja|entidade|codigo|conta|unidade|saldo|valor|receber|pagar|total)/i;
  let headerIndex = 0;
  let bestScore = -1;
  grid.slice(0, 20).forEach((row, index) => {
    const cells = row.filter((cell) => cell !== null && String(cell).trim() !== "");
    const score = cells.filter((cell) => keywords.test(String(cell))).length * 20 + cells.filter((cell) => typeof cell === "string").length;
    if (cells.length >= 2 && score > bestScore) { bestScore = score; headerIndex = index; }
  });

  const rawHeaders = grid[headerIndex] || [];
  const seen = new Map<string, number>();
  const columns = rawHeaders.map((cell, index) => {
    const base = String(cell ?? "").trim() || `Coluna ${index + 1}`;
    const count = seen.get(base) || 0;
    seen.set(base, count + 1);
    return count ? `${base} (${count + 1})` : base;
  });
  const rows = grid.slice(headerIndex + 1)
    .filter((row) => row.some((cell) => cell !== null && String(cell).trim() !== ""))
    .map((row) => Object.fromEntries(columns.map((column, index) => [column, row[index] ?? null])));
  if (!rows.length) throw new Error("Não encontrei linhas de dados abaixo do cabeçalho.");
  return { name: file.name, columns, rows };
}

function aggregate(kind: Kind, file: FileData, keyColumn: string, valueColumn: string) {
  const map = new Map<string, number>();
  file.rows.forEach((row) => {
    const key = normalizeChurchCode(kind, row[keyColumn]);
    if (!key) return;
    map.set(key, (map.get(key) || 0) + toNumber(row[valueColumn]));
  });
  return map;
}

function UploadCard({ kind, data, onFile }: { kind: Kind; data?: FileData; onFile: (file: File) => void }) {
  const input = useRef<HTMLInputElement>(null);
  const copy = labels[kind];
  return (
    <button
      className={`upload-card ${data ? "loaded" : ""}`}
      onClick={() => input.current?.click()}
      onDragOver={(event) => event.preventDefault()}
      onDrop={(event) => { event.preventDefault(); const file = event.dataTransfer.files[0]; if (file) onFile(file); }}
      type="button"
    >
      <input ref={input} type="file" accept=".pdf,.xlsx,.xls,.csv" hidden onChange={(event) => event.target.files?.[0] && onFile(event.target.files[0])} />
      <span className="upload-icon" aria-hidden="true">{data ? "✓" : "↑"}</span>
      <span className="upload-copy">
        <small>{copy.eyebrow}</small>
        <strong>{copy.title}</strong>
        <span>{data ? data.name : copy.hint}</span>
      </span>
      <span className="upload-action">{data ? "Trocar" : "Anexar"}</span>
    </button>
  );
}

function MappingCard({ kind, file, mapping, onChange }: { kind: Kind; file: FileData; mapping: Mapping; onChange: (next: Mapping) => void }) {
  const fields = [{ key: "balance", label: "Coluna de saldo" }];
  return (
    <div className="mapping-card">
      <div><small>{labels[kind].title}</small><strong>{file.rows.length.toLocaleString("pt-BR")} linhas</strong></div>
      <label>Identificador da igreja<select value={mapping.key} onChange={(e) => onChange({ ...mapping, key: e.target.value })}>{file.columns.map((c) => <option key={c}>{c}</option>)}</select></label>
      {fields.map((field) => <label key={field.key}>{field.label}<select value={mapping.balance} onChange={(e) => onChange({ ...mapping, balance: e.target.value })}>{file.columns.map((c) => <option key={c}>{c}</option>)}</select></label>)}
    </div>
  );
}

export default function Home() {
  const [files, setFiles] = useState<Partial<Record<Kind, FileData>>>({});
  const [mappings, setMappings] = useState<Partial<Record<Kind, Mapping>>>({});
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [showAll, setShowAll] = useState(false);
  const [resultTab, setResultTab] = useState<"corrections" | "reportTotals">("corrections");

  async function load(kind: Kind, file: File) {
    setError("");
    try {
      const parsed = file.name.toLowerCase().endsWith(".pdf") ? await parsePdf(kind, file) : await parseSpreadsheet(file);
      setFiles((current) => ({ ...current, [kind]: parsed }));
      setMappings((current) => ({ ...current, [kind]: suggestMapping(kind, parsed.columns) }));
    } catch (cause) {
      setError(`${labels[kind].title}: ${cause instanceof Error ? cause.message : "não foi possível ler o arquivo."}`);
    }
  }

  function loadDemo() {
    const entityColumns = ["Código da igreja", "Saldo final"];
    const acmsColumns = ["Código da igreja", "Igreja", "Saldo final"];
    const nextFiles: Record<Kind, FileData> = {
      receber: { name: "112111_junho.pdf", columns: entityColumns, rows: [{ "Código da igreja": "2147", "Saldo final": -1375.51 }, { "Código da igreja": "2113", "Saldo final": -776.15 }, { "Código da igreja": "2020", "Saldo final": 467.92 }] },
      pagar: { name: "112192_junho.pdf", columns: entityColumns, rows: [{ "Código da igreja": "14724", "Saldo final": -1375.51 }, { "Código da igreja": "11324", "Saldo final": -10939.31 }, { "Código da igreja": "2024", "Saldo final": 223.92 }] },
      acms: { name: "ACMS_junho.pdf", columns: acmsColumns, rows: [{ "Código da igreja": "147", Igreja: "Africana de Hortolândia", "Saldo final": -1375.51 }, { "Código da igreja": "113", Igreja: "Bofete", "Saldo final": -776.15 }, { "Código da igreja": "20", Igreja: "Apiaí Central", "Saldo final": 223.92 }] },
    };
    setFiles(nextFiles);
    setMappings({ receber: { key: entityColumns[0], balance: entityColumns[1] }, pagar: { key: entityColumns[0], balance: entityColumns[1] }, acms: { key: acmsColumns[0], balance: acmsColumns[2] } });
    setError("");
  }

  const ready = Boolean(files.receber && files.pagar && files.acms && mappings.receber?.balance && mappings.pagar?.balance && mappings.acms?.balance);
  const results = useMemo<ResultRow[]>(() => {
    if (!ready) return [];
    const entity111 = aggregate("receber", files.receber!, mappings.receber!.key, mappings.receber!.balance);
    const entity192 = aggregate("pagar", files.pagar!, mappings.pagar!.key, mappings.pagar!.balance);
    const acms = aggregate("acms", files.acms!, mappings.acms!.key, mappings.acms!.balance);
    const names = new Map(files.acms!.rows.map((row) => [normalizeChurchCode("acms", row[mappings.acms!.key]), String(row.Igreja || "")]));
    const keys = new Set([...entity111.keys(), ...entity192.keys(), ...acms.keys()]);
    return [...keys].sort((a, b) => a.localeCompare(b, "pt-BR", { numeric: true })).map((key) => {
      const current111 = Math.abs(entity111.get(key) || 0);
      const current192 = Math.abs(entity192.get(key) || 0);
      const target = Math.abs(acms.get(key) || 0);
      const adjust111 = target - current111;
      const adjust192 = target - current192;
      return { key, name: names.get(key) || "", entity111: current111, entity192: current192, acms: target, adjust111, adjust192, ok: Math.abs(adjust111) < 0.01 && Math.abs(adjust192) < 0.01 };
    });
  }, [files, mappings, ready]);

  const reportTotals = useMemo(() => {
    if (!ready) return { acms: 0, entity111: 0, entity192: 0 };
    const sum = (values: Map<string, number>) => Math.abs([...values.values()].reduce((total, value) => total + value, 0));
    return {
      acms: sum(aggregate("acms", files.acms!, mappings.acms!.key, mappings.acms!.balance)),
      entity111: sum(aggregate("receber", files.receber!, mappings.receber!.key, mappings.receber!.balance)),
      entity192: sum(aggregate("pagar", files.pagar!, mappings.pagar!.key, mappings.pagar!.balance)),
    };
  }, [files, mappings, ready]);

  const visible = results.filter((row) => (showAll || !row.ok) && `${row.key}${normalize(row.name)}`.includes(canonicalKey(search)));
  const divergences = results.filter((row) => !row.ok);
  const entityTotals = divergences.reduce((totals, row) => {
    if (row.adjust111 > 0) totals.debit111 += row.adjust111;
    if (row.adjust111 < 0) totals.credit111 += Math.abs(row.adjust111);
    if (row.adjust192 > 0) totals.credit192 += row.adjust192;
    if (row.adjust192 < 0) totals.debit192 += Math.abs(row.adjust192);
    return totals;
  }, { debit111: 0, credit111: 0, debit192: 0, credit192: 0 });
  const net111 = entityTotals.debit111 - entityTotals.credit111;
  const net192 = entityTotals.debit192 - entityTotals.credit192;
  const totalAdjustment = Math.abs(net111) + Math.abs(net192);

  function exportCsv() {
    const lines = [["Código", "Igreja", "ACMS", "112111 atual", "Ajuste 112111", "Ação 112111", "112192 atual", "Ajuste 112192", "Ação 112192"]];
    divergences.forEach((row) => lines.push([row.key, row.name, row.acms, row.entity111, Math.abs(row.adjust111), row.adjust111 >= 0 ? "Debitar" : "Creditar", row.entity192, Math.abs(row.adjust192), row.adjust192 >= 0 ? "Creditar" : "Debitar"].map(String)));
    const content = "\uFEFF" + lines.map((line) => line.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(";")).join("\n");
    const url = URL.createObjectURL(new Blob([content], { type: "text/csv;charset=utf-8" }));
    const anchor = document.createElement("a"); anchor.href = url; anchor.download = "correcoes-reconciliacao.csv"; anchor.click(); URL.revokeObjectURL(url);
  }

  return (
    <main className="acms-page">
      <header className="v-header v-horizontal-header"><a href="/" className="v-brand"><span className="vairis-mark">V</span><span>Vairis <b>Gestão</b></span></a><AccountControls /></header><MainNavigation current="conciliacao" />
      <section className="hero" id="top">
        <div className="hero-copy"><p className="kicker">RECONCILIAÇÃO MENSAL</p><h1>Três relatórios.<br /><em>Uma resposta clara.</em></h1><p>Anexe os saldos das entidades e o ACMS. O Vairis Gestão cruza igreja por igreja e mostra exatamente o que ajustar.</p><div className="hero-actions"><a href="#arquivos" className="primary">Começar reconciliação <span>→</span></a><button className="link-button" onClick={loadDemo}>Ver demonstração</button></div></div>
        <div className="hero-panel" aria-label="Resumo ilustrativo"><div className="panel-head"><span>FECHAMENTO DO MÊS</span><b>JUL/2026</b></div><div className="balance-line"><div><small>IGREJAS CONCILIADAS</small><strong>96,8%</strong></div><div className="ring"><span>30<small>/31</small></span></div></div><div className="mini-row"><span><i className="ok-dot" /> Saldos corretos</span><b>30</b></div><div className="mini-row warning"><span><i /> Requer ajuste</span><b>1</b></div><div className="signature">Feche o mês com confiança.</div></div>
      </section>

      <section className="workspace" id="arquivos">
        <div className="section-title"><div><p className="kicker">01 — ARQUIVOS DO MÊS</p><h2>Carregue os três relatórios</h2></div><p>Formatos aceitos: PDF, Excel (.xlsx, .xls) e CSV. Nos arquivos Excel, a primeira aba será usada.</p></div>
        <div className="upload-grid">{(["receber", "pagar", "acms"] as Kind[]).map((kind) => <UploadCard key={kind} kind={kind} data={files[kind]} onFile={(file) => load(kind, file)} />)}</div>
        <div className="match-rule"><b>Conferência por código e valor</b><span>Os nomes e o sinal negativo são ignorados. Na 112192, o final 24 é removido automaticamente.</span></div>
        {error && <div className="error" role="alert">{error}</div>}

        {Object.keys(files).length > 0 && <div className="mapping-section"><div className="section-title compact"><div><p className="kicker">02 — CONFERÊNCIA DAS COLUNAS</p><h2>Confirme o que cada coluna representa</h2></div><p>Já fizemos uma sugestão automática. Ajuste apenas se necessário.</p></div><div className="mapping-grid">{(["receber", "pagar", "acms"] as Kind[]).map((kind) => files[kind] && mappings[kind] && <MappingCard key={kind} kind={kind} file={files[kind]!} mapping={mappings[kind]!} onChange={(next) => setMappings((current) => ({ ...current, [kind]: next }))} />)}</div></div>}

        <nav className="result-tabs" aria-label="Visualizações do resultado">
          <button className={resultTab === "corrections" ? "active" : ""} onClick={() => setResultTab("corrections")}>Correções</button>
          <button className={resultTab === "reportTotals" ? "active" : ""} onClick={() => setResultTab("reportTotals")}>Totais dos relatórios</button>
        </nav>

        {!ready && <div className="tab-empty"><strong>{resultTab === "reportTotals" ? "Totais dos relatórios" : "Correções"}</strong><span>Carregue os três relatórios para visualizar esta aba.</span></div>}

        {ready && <section className="results">
          <div hidden={resultTab !== "corrections"}>
          <div className="section-title compact"><div><p className="kicker">03 — RESULTADO</p><h2>{divergences.length ? `${divergences.length} ${divergences.length === 1 ? "igreja precisa" : "igrejas precisam"} de correção` : "Todos os saldos estão conciliados"}</h2></div><button className="secondary" onClick={exportCsv} disabled={!divergences.length}>Baixar correções ↓</button></div>
          <div className="summary-grid"><article><small>IGREJAS ANALISADAS</small><strong>{results.length}</strong><span>nos três relatórios</span></article><article className="success"><small>SALDOS CORRETOS</small><strong>{results.length - divergences.length}</strong><span>nenhuma ação necessária</span></article><article className="attention"><small>VALOR LÍQUIDO A AJUSTAR</small><strong>{money.format(totalAdjustment)}</strong><span>soma dos ajustes líquidos das entidades</span></article></div>
          <div className="table-tools"><label className="search">⌕<input aria-label="Buscar igreja" placeholder="Buscar igreja" value={search} onChange={(e) => setSearch(e.target.value)} /></label><div className="toggle"><button className={!showAll ? "active" : ""} onClick={() => setShowAll(false)}>Só divergências</button><button className={showAll ? "active" : ""} onClick={() => setShowAll(true)}>Todas</button></div></div>
          <div className="table-wrap"><table><thead><tr><th>Igreja</th><th>ACMS</th><th>112111 atual</th><th>Correção 112111</th><th>112192 atual</th><th>Correção 112192</th><th>Status</th></tr></thead><tbody>{visible.map((row) => <tr key={row.key}><td><b>{row.key}</b><span className="church-name">{row.name}</span></td><td>{money.format(row.acms)}</td><td>{money.format(row.entity111)}</td><td className={row.adjust111 ? "difference" : "muted"}>{row.adjust111 ? <><b>{row.adjust111 > 0 ? "Debitar" : "Creditar"}</b><span>{money.format(Math.abs(row.adjust111))}</span></> : "—"}</td><td>{money.format(row.entity192)}</td><td className={row.adjust192 ? "difference" : "muted"}>{row.adjust192 ? <><b>{row.adjust192 > 0 ? "Creditar" : "Debitar"}</b><span>{money.format(Math.abs(row.adjust192))}</span></> : "—"}</td><td><span className={`status ${row.ok ? "ok" : "review"}`}>{row.ok ? "Conciliado" : "Ajustar"}</span></td></tr>)}</tbody></table>{!visible.length && <div className="empty">Nenhuma igreja encontrada neste filtro.</div>}</div>
          <p className="note"><b>Como calculamos:</b> o sinal negativo é ignorado na comparação. Por exemplo, R$ 240,86 e -R$ 240,86 são considerados o mesmo saldo. A correção usa somente a diferença entre os valores absolutos.</p>
          <section className="adjustment-totals">
            <div className="totals-heading"><div><p className="kicker">04 — TOTAIS PARA LANÇAMENTO</p><h2>Total de ajuste por entidade</h2></div><p>Débitos e créditos são compensados para formar o ajuste líquido.</p></div>
            <div className="entity-total-grid">
              <article>
                <header><span>ENTIDADE</span><strong>112111</strong></header>
                <div className="total-row"><span>Total a debitar</span><b>{money.format(entityTotals.debit111)}</b></div>
                <div className="total-row"><span>Total a creditar</span><b>{money.format(entityTotals.credit111)}</b></div>
                <div className="total-row grand"><span>{net111 >= 0 ? "Líquido a debitar" : "Líquido a creditar"}</span><b>{money.format(Math.abs(net111))}</b></div>
              </article>
              <article>
                <header><span>ENTIDADE</span><strong>112192</strong></header>
                <div className="total-row"><span>Total a debitar</span><b>{money.format(entityTotals.debit192)}</b></div>
                <div className="total-row"><span>Total a creditar</span><b>{money.format(entityTotals.credit192)}</b></div>
                <div className="total-row grand"><span>{net192 >= 0 ? "Líquido a debitar" : "Líquido a creditar"}</span><b>{money.format(Math.abs(net192))}</b></div>
              </article>
            </div>
          </section>
          </div>
          <div className="report-totals-pane" hidden={resultTab !== "reportTotals"}>
            <div className="section-title compact"><div><p className="kicker">03 — TOTAIS DOS RELATÓRIOS</p><h2>Saldo total informado em cada arquivo</h2></div><p>O total líquido de cada relatório é apresentado pelo valor absoluto.</p></div>
            <div className="report-total-grid">
              <article className="reference">
                <small>RELATÓRIO DE REFERÊNCIA</small><h3>ACMS</h3><strong>{money.format(reportTotals.acms)}</strong><span>{files.acms!.rows.length.toLocaleString("pt-BR")} registros identificados</span>
              </article>
              <article>
                <small>ENTIDADE</small><h3>112111</h3><strong>{money.format(reportTotals.entity111)}</strong><span className={Math.abs(reportTotals.entity111 - reportTotals.acms) < .01 ? "matched" : "unmatched"}>{Math.abs(reportTotals.entity111 - reportTotals.acms) < .01 ? "Fecha com o ACMS" : `Diferença de ${money.format(Math.abs(reportTotals.entity111 - reportTotals.acms))}`}</span>
              </article>
              <article>
                <small>ENTIDADE</small><h3>112192</h3><strong>{money.format(reportTotals.entity192)}</strong><span className={Math.abs(reportTotals.entity192 - reportTotals.acms) < .01 ? "matched" : "unmatched"}>{Math.abs(reportTotals.entity192 - reportTotals.acms) < .01 ? "Fecha com o ACMS" : `Diferença de ${money.format(Math.abs(reportTotals.entity192 - reportTotals.acms))}`}</span>
              </article>
            </div>
            <p className="note"><b>Importante:</b> estes são os totais líquidos dos arquivos completos. Eles são diferentes do total de correções por igreja mostrado na outra aba.</p>
          </div>
        </section>}
      </section>
      <footer><span>Vairis Gestão</span><p>Uma ferramenta simples para fechar o mês com segurança.</p><small>Seus arquivos não são enviados nem armazenados.</small></footer>
    </main>
  );
}



