import { requireChatGPTUser } from '../chatgpt-auth';
import Reconciliation from './reconciliation';
export const dynamic = 'force-dynamic';
export default async function Page() { await requireChatGPTUser('/conciliacao'); return <Reconciliation />; }
