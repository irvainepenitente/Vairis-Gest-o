import { getChatGPTUser, chatGPTSignInPath } from './chatgpt-auth';
import Workspace from './workspace';
import AccountControls from './account-controls';
export const dynamic = 'force-dynamic';
export default async function Home() {
  const user = await getChatGPTUser();
  if (!user) return <main className="login-screen v-branded-login"><section className="v-login-cover"><img src="/vairis-capa.png" alt="Vairis Gestão — Contabilidade, Finanças e Gestão" width="2048" height="683" fetchPriority="high" /></section><div className="login-card"><span className="vairis-mark">V</span><p className="overline">SEU ESPAÇO DE TRABALHO</p><h1>Vairis Gestão</h1><p>Documentos, conciliações e relatórios em um só lugar.</p><a className="v-button" href={chatGPTSignInPath('/')} target="_top">Entrar com ChatGPT</a><small>Acesso pessoal e restrito à sua conta.</small><AccountControls signedIn={false} /></div></main>;
  return <Workspace email={user.email} />;
}

