"use client";
const items = [
  { id: 'inicio', label: 'Visão geral', href: '/' },
  { id: 'documentos', label: 'Documentos', href: '/?view=documentos' },
  { id: 'conciliacao', label: 'Conciliação ACMS', href: '/conciliacao' },
  { id: 'relatorios', label: 'Relatórios', href: '/?view=relatorios' },
  { id: 'balancos', label: 'Análise de Balanços', href: '/balancos' },
  { id: 'fluxo-caixa', label: 'Fluxo de Caixa', href: '/?view=fluxo-caixa' },
  { id: 'avisos-arm', label: 'Avisos ARM', href: '/?view=avisos-arm' },
  { id: 'eventos-apso', label: 'Eventos APSo', href: '/?view=eventos-apso' },
  { id: 'integracoes', label: 'Integrações', href: '/?view=integracoes' }
];
export default function MainNavigation({ current, onNavigate }: { current: string; onNavigate?: (view: string) => void }) {
  return <nav className="v-topnav" aria-label="Menu principal"><div className="v-topnav-inner">{items.map(item => <a key={item.id} href={item.href} className={current===item.id?'selected':''} aria-current={current===item.id?'page':undefined} onClick={event => { if(onNavigate && item.id!=='conciliacao' && item.id!=='balancos' && event.button===0 && !event.ctrlKey && !event.metaKey && !event.shiftKey && !event.altKey) { event.preventDefault();onNavigate(item.id);window.history.replaceState(null,'',item.href); } }}>{item.label}</a>)}</div></nav>;
}
