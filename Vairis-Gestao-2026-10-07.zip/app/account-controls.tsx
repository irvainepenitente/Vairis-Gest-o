"use client";
import { useRef } from 'react';
import InstallApp from './install-app';
export default function AccountControls({ disabled = false, signedIn = true }: { disabled?: boolean; signedIn?: boolean }) {
  const dialog = useRef<HTMLDialogElement>(null);
  return <><div className="v-account-actions" aria-label="Controles da conta"><InstallApp />
    <button type="button" className="v-account-button" disabled={disabled} onClick={() => window.location.reload()}>Atualizar</button>
    <button type="button" className="v-account-button" onClick={() => dialog.current?.showModal()}>Trocar senha</button>
    {signedIn && <a className="v-account-button v-signout" href="/signout-with-chatgpt?return_to=%2F" target="_top">Sair</a>}
  </div><dialog ref={dialog} className="v-password-dialog" aria-labelledby="password-title"><div className="v-password-content"><p className="overline">SEGURANÇA DA CONTA</p><h2 id="password-title">Trocar senha</h2><p>Seu acesso ao Vairis Gestão usa sua conta ChatGPT. A senha é alterada nas configurações dessa conta.</p><ol><li>Abra o ChatGPT e entre na sua conta.</li><li>Acesse <strong>Configurações → Conta</strong>.</li><li>Escolha a opção para adicionar ou atualizar sua senha.</li></ol><p className="v-helper">Se você entra com Google, Microsoft ou Apple, a senha desse acesso é gerenciada pelo respectivo serviço.</p><div className="v-password-actions"><a className="v-button" href="https://chatgpt.com/" target="_blank" rel="noopener noreferrer">Abrir ChatGPT</a><button type="button" className="v-button v-subtle" onClick={() => dialog.current?.close()}>Fechar</button></div><a className="v-password-help" href="https://help.openai.com/pt-br/articles/4936828-resetting-or-changing-your-chatgpt-password" target="_blank" rel="noopener noreferrer">Ver instruções oficiais</a></div></dialog></>;
}

