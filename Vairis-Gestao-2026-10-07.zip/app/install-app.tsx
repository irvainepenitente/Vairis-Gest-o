"use client";
import { useEffect, useRef, useState } from 'react';
type Device = 'windows' | 'android' | 'iphone';
type InstallEvent = Event & { prompt(): Promise<void>; userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }> };
const guides: Record<Device, { title: string; browser: string; steps: string[]; source: string }> = {
  windows: { title: 'Windows', browser: 'Microsoft Edge ou Google Chrome', steps: ['Abra este site no Microsoft Edge ou Google Chrome, fora do navegador interno do ChatGPT.', 'Se o ícone de instalar não aparecer na barra de endereço, abra o menu do navegador e procure a opção de instalar esta página como aplicativo.', 'No Edge, você também pode usar o menu ⋯ → Mais ferramentas → Aplicativos → Instalar este site como aplicativo.', 'Depois de instalar, abra o Vairis pelo menu Iniciar. Você pode fixá-lo na barra de tarefas.'], source: 'https://support.microsoft.com/en-us/edge/install-manage-or-uninstall-apps-in-microsoft-edge' },
  android: { title: 'Android', browser: 'Google Chrome', steps: ['Abra este site no Chrome do seu celular.', 'Toque no menu ⋮ → Instalar e criar atalho → Instalar. Em algumas versões, a opção aparece como “Adicionar à tela inicial”.', 'Confirme a instalação e abra o Vairis pelo ícone na tela inicial.'], source: 'https://support.google.com/chrome/answer/9658361?co=GENIE.Platform%3DAndroid&hl=pt-BR' },
  iphone: { title: 'iPhone / iPad', browser: 'Safari', steps: ['Abra este site no Safari do seu iPhone ou iPad.', 'Toque em Compartilhar e escolha “Adicionar à Tela de Início”.', 'Se aparecer a opção “Abrir como App da Web”, ative-a. Toque em Adicionar.', 'Abra o Vairis pelo ícone na tela inicial e entre com sua conta ChatGPT.'], source: 'https://support.apple.com/en-lamr/guide/iphone/iphea86e5236/ios' }
};
export default function InstallApp() {
  const dialog = useRef<HTMLDialogElement>(null); const pending = useRef<InstallEvent | null>(null);
  const [platform,setPlatform] = useState<Device>('windows'); const [current,setCurrent] = useState<Device>('windows');
  const [ready,setReady] = useState(false); const [installed,setInstalled] = useState(false); const [working,setWorking] = useState(false);
  const [message,setMessage] = useState(''); const [address,setAddress] = useState('');
  useEffect(() => {
    const ua = navigator.userAgent; const device: Device = /Android/i.test(ua) ? 'android' : /iPhone|iPad|iPod/i.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1) ? 'iphone' : 'windows';
    setPlatform(device);setCurrent(device);setAddress(window.location.origin+'/');
    const media = window.matchMedia('(display-mode: standalone)');
    setInstalled(media.matches || Boolean((navigator as Navigator & { standalone?: boolean }).standalone));
    const before = (event: Event) => { event.preventDefault(); pending.current=event as InstallEvent;setReady(true); };
    const complete = () => { pending.current=null;setReady(false);setInstalled(true);setMessage('Aplicativo instalado. Abra o Vairis pelo ícone no seu dispositivo.'); };
    window.addEventListener('beforeinstallprompt',before); window.addEventListener('appinstalled',complete);
    if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js', { updateViaCache: 'none' }).catch(() => {});
    return () => { window.removeEventListener('beforeinstallprompt',before);window.removeEventListener('appinstalled',complete); };
  },[]);
  async function install() {
    if (platform==='iphone' || platform!==current || !pending.current) { setMessage('Siga os passos abaixo no dispositivo escolhido. A instalação é concluída pelo navegador.'); return; }
    setWorking(true);setMessage('');
    const event=pending.current;pending.current=null;setReady(false);
    try { await event.prompt();const choice=await event.userChoice;setMessage(choice.outcome==='accepted'?'Instalação solicitada. Aguarde a confirmação do navegador.':'Você pode instalar quando quiser usando o menu do navegador.'); }
    catch { setMessage('Abra este site no navegador indicado e siga as instruções abaixo para instalar.'); }
    finally { setWorking(false); }
  }
  async function copyAddress() { try { await navigator.clipboard.writeText(address);setMessage('Endereço copiado. Cole no navegador do computador ou celular.'); } catch { setMessage('Selecione e copie o endereço abaixo para abrir no navegador do seu dispositivo.'); } }
  const guide=guides[platform];const canInstall=ready && platform===current && platform!=='iphone' && !installed;
  return <><button type="button" className="v-account-button v-download-button" onClick={()=>{setMessage('');dialog.current?.showModal();}}>Baixar app</button>
  <dialog ref={dialog} className="v-install-dialog" aria-labelledby="install-title"><div className="v-install-head"><div><p className="overline">VAIRIS NO SEU DISPOSITIVO</p><h2 id="install-title">Baixar e instalar o app</h2></div><button type="button" aria-label="Fechar opções de instalação" className="v-install-close" onClick={()=>dialog.current?.close()}>×</button></div>
  <div className="v-install-body"><p className="v-install-intro">Escolha seu dispositivo para instalar o Vairis Gestão com ícone próprio. O aplicativo usa seu login e seus documentos salvos no sistema.</p>
  <div className="v-install-devices" aria-label="Escolha o dispositivo">{(Object.keys(guides) as Device[]).map(device=><button key={device} type="button" aria-pressed={platform===device} className={platform===device?'selected':''} onClick={()=>{setPlatform(device);setMessage('');}}><span aria-hidden="true">{device==='windows'?'▦':device==='android'?'▯':'◉'}</span><b>{guides[device].title}</b><small>{device==='windows'?'Computador':'Celular / tablet'}</small></button>)}</div>
  <section className="v-install-guide"><div className="v-install-guide-head"><div><h3>{guide.title}</h3><p>{guide.browser}</p></div><button type="button" className="v-button" disabled={working} onClick={install}>{working?'Aguarde…':canInstall?'Instalar agora':platform==='iphone'?'Como adicionar à tela inicial':'Como instalar'}</button></div>
  {installed && platform===current && <p className="v-install-success">Você já está usando o Vairis em modo aplicativo.</p>}
  {message && <p className="v-notice" role="status">{message}</p>}
  <ol>{guide.steps.map(step=><li key={step}>{step}</li>)}</ol><a className="v-password-help" href={guide.source} target="_blank" rel="noopener noreferrer">Ajuda oficial de instalação</a></section>
  <div className="v-install-address"><label htmlFor="install-address">Endereço para abrir em outro dispositivo</label><div><input id="install-address" value={address} readOnly onFocus={event=>event.currentTarget.select()} /><button className="v-account-button" type="button" onClick={copyAddress}>Copiar link</button></div></div>
  <p className="v-helper">Esta versão é instalada pelo navegador. É necessário acesso à internet para usar o sistema.</p></div></dialog></>;
}
